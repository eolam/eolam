"use client";

import type {SetStateAction} from "react";
import type {VideoType} from "@/interfaces/exerciseType.interface";
import type {InVideo} from "@/app/api/_models/Video.model";

import {useEffect, useState} from "react";
import {ArrowRightIcon, ArrowLeftIcon} from "@heroicons/react/24/outline";

import NewExerciseForm from "@/components/newExerciseForm";
import AllExercises from "@/components/allExercises";
import {getAllVideos} from "@/utils/fetchExercise.util";

import {Input, Button, IconButton} from "../../../mTailwind/tailwindMaterial";

export default function ExercisesPage() {
  const [videos, setVideos] = useState<InVideo[]>();
  const [exercises, setExercises] = useState<VideoType[]>();

  const [active, setActive] = useState(1);

  const [search, setSearch] = useState("");

  const [totalPages, setTotalPages] = useState(1);

  const pages = Array.from({length: totalPages}, (_, index) => index + 1);

  const getItemProps = (index: number) =>
    // eslint-disable-next-line @typescript-eslint/no-unsafe-return
    ({
      variant: active === index ? "filled" : "text",
      color: "white",
      onClick: () => setActive(index),
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    }) as any;

  const next = () => {
    if (active === 5) return;

    setActive(active + 1);
  };

  const prev = () => {
    if (active === 1) return;

    setActive(active - 1);
  };

  const loadExercises = async (page: number, search?: string) => {
    const response = await getAllVideos(page, search);

    if ("error" in response) return;

    setExercises(response.results), setTotalPages(response.totalPages);
  };

  const handleSearch = (e: {target: {value: SetStateAction<string>}}) => {
    setSearch(e.target.value);
    if (search !== "") {
      loadExercises(active, search);
    } else {
      loadExercises(active);
    }
  };

  useEffect(() => {
    loadVideos();

    loadExercises(active, search);
  }, [active, search]);

  const loadVideos = async () => {
    const response = await fetch("/api/video");
    const data = (await response.json()) as {message: InVideo[]};

    console.log(JSON.stringify(data));

    setVideos(data.message);
  };

  return (
    <div className="flex-col">
      <div className="ml-8 mr-8 mt-8 flex justify-between">
        <div className="text-xl font-bold italic tracking-wide">Exercises</div>
        <div className="w-72">
          <Input
            color="white"
            crossOrigin={undefined}
            label="Search exercise..."
            onChange={handleSearch}
          />
        </div>
      </div>
      <div className="h-64">
        {videos ? (
          <AllExercises loadExercises={loadExercises} page={active} videos={videos} />
        ) : null}
      </div>

      <div className="mb-4 mt-8 flex w-full justify-center">
        <div className="flex items-center gap-4">
          <Button
            className="flex items-center gap-2"
            color="white"
            disabled={active === 1}
            variant="text"
            onClick={prev}
          >
            <ArrowLeftIcon className="h-4 w-4" strokeWidth={2} /> Previous
          </Button>

          <div className="flex items-center gap-2">
            {pages.map((page) => {
              return (
                <IconButton key={page} {...getItemProps(page)}>
                  {page}
                </IconButton>
              );
            })}
          </div>
          <Button
            className="flex items-center gap-2"
            color="white"
            disabled={active === totalPages}
            variant="text"
            onClick={next}
          >
            Next
            <ArrowRightIcon className="h-4 w-4" strokeWidth={2} />
          </Button>
        </div>
      </div>

      <NewExerciseForm loadExercises={loadExercises} page={active} />
    </div>
  );
}
