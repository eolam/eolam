import {bgAppDark} from "@/assets/styles/colors";

import NavBar from "../../components/NavBar";

export default function AdminDasboardLayout({children}: {children: React.ReactNode}) {
  return (
    <div className={`${bgAppDark} h-full`}>
      <NavBar />
      <main className="max-h-full max-w-full py-2 ">{children} </main>
    </div>
  );
}
