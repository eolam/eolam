import {getUserCurrentSession} from "@/utils/fetchUsers";
import CardMyProfile from "@/components/CardMyProfile";

export default async function ProfilePage() {
  let currentIDSession;

  try {
    const sessionCookie = await getUserCurrentSession();

    if ("data" in sessionCookie) {
      if (sessionCookie.data) {
        currentIDSession = sessionCookie.data[0].user;
      }
    }
  } catch (error) {}

  return (
    <div className="flex max-h-max w-full justify-center">
      <CardMyProfile sessionUserCookie={currentIDSession} />
    </div>
  );
}
