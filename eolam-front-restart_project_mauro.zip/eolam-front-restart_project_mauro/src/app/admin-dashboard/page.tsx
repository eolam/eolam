import {faDumbbell, faUser, faUsers} from "@fortawesome/free-solid-svg-icons";

import {buttonColorSecondary, hoverColor, textWithe} from "@/assets/styles/colors";

import Button from "../../components/button";
import MessageDay from "../../components/messageDay";

export default async function AdminPage() {
  return (
    <div className="mb-48 flex justify-around">
      <div className="felx w-1/5 flex-col">
        <Button
          color={buttonColorSecondary}
          hoverColor={hoverColor}
          icon={faUsers}
          route="/admin-dashboard/users"
          text="User list"
          textColor={textWithe}
          widthIcon="w-6"
        />
        <Button
          color={buttonColorSecondary}
          hoverColor={hoverColor}
          icon={faDumbbell}
          route="/admin-dashboard/exercises"
          text="Exercises"
          textColor={textWithe}
          widthIcon="w-6"
        />
        <Button
          color={buttonColorSecondary}
          hoverColor={hoverColor}
          icon={faUser}
          route="/admin-dashboard/myprofile"
          text="My profile"
          textColor={textWithe}
          widthIcon="w-4"
        />
      </div>
      <div className="mt-10 w-1/3 p-4">
        <MessageDay />
      </div>
    </div>
  );
}
