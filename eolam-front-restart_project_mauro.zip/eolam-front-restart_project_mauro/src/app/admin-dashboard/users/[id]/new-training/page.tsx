"use client";
import type {GetExercisesByReportAndStage} from "@/interfaces/exerciseUser";

import {useEffect, useState} from "react";

import {bgAppDark} from "@/assets/styles/colors";
import NewActivationTable from "@/components/NewActivationTable";
import NewStrengthTable from "@/components/NewStrengthTable";
import {changeStatusTraining} from "@/utils/fetchReport.util";
import TotalAllSRW from "@/components/TotalAllSRW";
import {getExerciseByReportAndStage} from "@/utils/fetchExerciseUser.util";
import {TrainingStage} from "@/utils/commonResourcesForms.util";
import {getNewReport} from "@/utils/localStorage/newReport";
import {isResponseOk} from "@/interfaces/response.interface";

import NewMobilityTable from "../../../../../components/newMobilityTable";
import {Button, Card, CardHeader} from "../../../../../mTailwind/tailwindMaterial";

export default function NewTrainingPage() {
  const [valueName, setValueName] = useState<string | null>(null);

  const [currentReport, setCurrentReport] = useState({
    report_number: 0,
    week_number: 0,
    status: false,
    id: 0,
  });

  const [mobilityExercises, setMobilityExercises] = useState<GetExercisesByReportAndStage[]>();

  const [activationExercises, setActivationExercises] = useState<GetExercisesByReportAndStage[]>();

  const [strengthExercises, setStrengthExercises] = useState<GetExercisesByReportAndStage[]>();

  useEffect(() => {
    const username = localStorage.getItem("username");
    const dataReport = getNewReport();

    setValueName(username);
    if (dataReport) {
      setCurrentReport(dataReport);
    }
  }, []);

  const handleClick = async () => {
    const {id, status} = currentReport;

    await changeStatusTraining(!status, id);
    setCurrentReport({...currentReport, status: !status});
    localStorage.setItem("new_exercise", JSON.stringify(currentReport));
  };

  const loadAllExercises = async () => {
    const currentReport = getNewReport();

    if (currentReport && "id" in currentReport) {
      const id_report = currentReport.id;

      const responseMobility = await getExerciseByReportAndStage(id_report, TrainingStage.Mobility);

      if ("error" in responseMobility) return;

      if (isResponseOk(responseMobility)) setMobilityExercises(responseMobility.results);

      const responseActivation = await getExerciseByReportAndStage(
        id_report,
        TrainingStage.Activation,
      );

      if ("error" in responseActivation) return;
      setActivationExercises(responseActivation.results);

      const responseStrength = await getExerciseByReportAndStage(id_report, TrainingStage.Strength);

      if ("error" in responseStrength) return;
      setStrengthExercises(responseStrength.results);
    }
  };

  useEffect(() => {
    loadAllExercises();
  }, []);

  return (
    <Card className="w-full rounded-none bg-blue-gray-900">
      <CardHeader className={`m-4 p-4 ${bgAppDark} rounded-none text-white`}>
        <div className="flex justify-between font-sans">
          <div> New training to {valueName} </div>
          <div> Week number: {currentReport.week_number} </div>
          <div> Report number: {currentReport.report_number} </div>
        </div>
      </CardHeader>
      <div className="mx-4 flex justify-center bg-blue-gray-100 p-2 text-black">Mobility</div>
      <NewMobilityTable />
      <div className="mx-4 flex justify-center bg-blue-gray-100 p-2 text-black">Activation</div>
      <NewActivationTable />
      <div className="mx-4 flex justify-center bg-blue-gray-100 p-2 text-black">Strength</div>
      <NewStrengthTable />
      <div className="flex flex-col justify-center">
        <div className="mx-4 mb-5 bg-pink-900 p-2 text-white">
          {mobilityExercises && activationExercises && strengthExercises ? (
            <TotalAllSRW
              inForm
              exActivation={activationExercises}
              exMobility={mobilityExercises}
              exStrength={strengthExercises}
            />
          ) : null}
        </div>
        <div className="flex justify-center">
          <Button
            className="mb-8 w-1/5 hover:bg-pink-700"
            color="gray"
            size="md"
            onClick={handleClick}
          >
            {" "}
            {currentReport.status ? "Disable training" : "Save training"}
          </Button>
        </div>
      </div>
    </Card>
  );
}
