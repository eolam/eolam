"use client";

import {useParams} from "next/navigation";

import TrainingHistoryCard from "@/components/TrainingHistoryCard";

import CardDetailUser from "../../../../components/CardDetailUser";

export default function UserDetailPage() {
  const params = useParams();
  const id = params?.id;

  return (
    <div className="flex h-screen w-11/12 justify-center">
      <CardDetailUser id={id as string} />
      <TrainingHistoryCard />
    </div>
  );
}
