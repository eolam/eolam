"use client";

import type {GetExercisesByReportAndStage} from "@/interfaces/exerciseUser";

import {useParams} from "next/navigation";
import {useEffect, useState} from "react";

import {getExerciseByReportAndStage} from "@/utils/fetchExerciseUser.util";
import {TrainingStage} from "@/utils/commonResourcesForms.util";
import {bgAppDark} from "@/assets/styles/colors";
import ViewTableTraining from "@/components/ViewTableTraining";
import TotalSRWforStage from "@/components/TotalSRWforStage";
import TotalAllSRW from "@/components/TotalAllSRW";
import {getNewReport} from "@/utils/localStorage/newReport";

import {Button, Collapse, Typography} from "../../../../../../mTailwind/tailwindMaterial";

export default function ReportByIdPage() {
  const params = useParams();
  const idReport = params?.idReport;

  const TABLE_HEAD = ["Exercise", "Series", "Repetitions", "Weight", "Rpe", "Interval"];

  const [mobilityExercises, setMobilityExercises] = useState<GetExercisesByReportAndStage[]>();

  const [activationExercises, setActivationExercises] = useState<GetExercisesByReportAndStage[]>();

  const [strengthExercises, setStrengthExercises] = useState<GetExercisesByReportAndStage[]>();

  const [openMobility, setOpenMobility] = useState<boolean>(false);
  const [openActivation, setOpenActivation] = useState<boolean>(false);
  const [openStrength, setOpenStrength] = useState<boolean>(false);

  const [valueName, setValueName] = useState<string | null>(null);
  const [date, setDate] = useState<string | null>(null);

  useEffect(() => {
    const username = localStorage.getItem("username");
    const currentReport = getNewReport();

    if (currentReport && "date" in currentReport) {
      currentReport.date && setDate(currentReport.date);
      setValueName(username);
    }
  }, []);

  useEffect(() => {
    const loadAllExercises = async () => {
      const id_report = Number(idReport as string);

      const responseMobility = await getExerciseByReportAndStage(id_report, TrainingStage.Mobility);

      if ("error" in responseMobility) return;
      setMobilityExercises(responseMobility.results);

      const responseActivation = await getExerciseByReportAndStage(
        id_report,
        TrainingStage.Activation,
      );

      if ("error" in responseActivation) return;
      setActivationExercises(responseActivation.results);

      const responseStrength = await getExerciseByReportAndStage(id_report, TrainingStage.Strength);

      if ("error" in responseStrength) return;
      setStrengthExercises(responseStrength.results);
    };

    loadAllExercises();
  }, [idReport]);

  return (
    <div className="mt-8 flex w-full flex-col justify-center pb-8 ">
      <div className="mx-4 flex justify-between text-2xl font-thin">
        <div>{valueName}</div>
        <div>{date}</div>
      </div>
      <div className={`flex flex-col text-center ${bgAppDark} w-full`}>
        <Button
          className="mx-4 flex justify-center rounded-none bg-blue-gray-100 p-2 font-sans text-base font-semibold capitalize text-black"
          onClick={() => setOpenMobility(!openMobility)}
        >
          Mobility
        </Button>
        <div>
          <Collapse className="pl-2 pr-2" open={openMobility}>
            <div className="mt-4 flex justify-center ">
              {TABLE_HEAD.map((head) => (
                <div
                  key={head}
                  className={` content-center ${head == "Exercise" ? " w-3/12" : "w-2/12"}`}
                >
                  <Typography
                    className="mb-4 font-bold opacity-70 "
                    color="white"
                    variant="paragraph"
                  >
                    {head}
                  </Typography>
                </div>
              ))}
            </div>

            {mobilityExercises?.map((exercise, index) => {
              return (
                <div key={exercise.id}>
                  <ViewTableTraining exercise={exercise} index={index} />
                </div>
              );
            })}
          </Collapse>
        </div>
        <div className="mx-4  mb-5 bg-blue-gray-300 p-2">
          {mobilityExercises ? <TotalSRWforStage exercises={mobilityExercises} /> : null}
        </div>
      </div>

      <div className={`flex flex-col text-center ${bgAppDark} w-full`}>
        <Button
          className="mx-4 flex justify-center rounded-none bg-blue-gray-100 p-2 font-sans text-base font-semibold capitalize text-black"
          onClick={() => setOpenActivation(!openActivation)}
        >
          Activation
        </Button>
        <div>
          <Collapse className="pl-2 pr-2" open={openActivation}>
            <div className="mt-4 flex justify-center ">
              {TABLE_HEAD.map((head) => (
                <div
                  key={head}
                  className={` content-center ${head == "Exercise" ? " w-3/12" : "w-2/12"}`}
                >
                  <Typography
                    className="mb-4 font-bold opacity-70 "
                    color="white"
                    variant="paragraph"
                  >
                    {head}
                  </Typography>
                </div>
              ))}
            </div>
            {activationExercises?.map((exercise, index) => {
              return (
                <div key={exercise.id}>
                  <ViewTableTraining exercise={exercise} index={index} />
                </div>
              );
            })}
          </Collapse>
        </div>
        <div className="mx-4  mb-5 bg-blue-gray-300 p-2">
          {activationExercises ? <TotalSRWforStage exercises={activationExercises} /> : null}
        </div>
      </div>

      <div className={`flex flex-col text-center ${bgAppDark} w-full`}>
        <Button
          className="mx-4 flex justify-center rounded-none bg-blue-gray-100 p-2 font-sans text-base font-semibold capitalize text-black"
          onClick={() => setOpenStrength(!openStrength)}
        >
          Strength
        </Button>
        <div>
          <Collapse className="pl-2 pr-2" open={openStrength}>
            <div className="mt-4 flex justify-center ">
              {TABLE_HEAD.map((head) => (
                <div
                  key={head}
                  className={` content-center ${head == "Exercise" ? " w-3/12" : "w-2/12"}`}
                >
                  <Typography
                    className="mb-4 font-bold opacity-70 "
                    color="white"
                    variant="paragraph"
                  >
                    {head}
                  </Typography>
                </div>
              ))}
            </div>
            {strengthExercises?.map((exercise, index) => {
              return (
                <div key={exercise.id}>
                  <ViewTableTraining exercise={exercise} index={index} />
                </div>
              );
            })}
          </Collapse>
        </div>
        <div className="mx-4  mb-5 bg-blue-gray-300 p-2">
          {strengthExercises ? <TotalSRWforStage exercises={strengthExercises} /> : null}
        </div>
      </div>
      <div className={`flex flex-col text-center ${bgAppDark} w-full`}>
        <div className="mx-4  mb-5 bg-pink-900 p-2">
          {mobilityExercises && activationExercises && strengthExercises ? (
            <TotalAllSRW
              exActivation={activationExercises}
              exMobility={mobilityExercises}
              exStrength={strengthExercises}
            />
          ) : null}
        </div>
      </div>
    </div>
  );
}
