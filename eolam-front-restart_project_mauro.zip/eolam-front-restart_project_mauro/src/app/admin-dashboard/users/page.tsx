"use client";
import type {ListUserReduced} from "@/interfaces/user.interfaces";
import type {UserListResponse} from "@/app/api/_services/UserService";
import type {ResponseOk} from "@/interfaces/response.interface";

import {useEffect, useState} from "react";
import {ArrowRightIcon, ArrowLeftIcon} from "@heroicons/react/24/outline";

import {bgActiveColor, bgInactiveColor, textWithe} from "@/assets/styles/colors";
import UserStateButton from "@/components/userStateButton";
import ListTableUsers from "@/components/ListTableUsers";
import LoadingComponent from "@/components/LoadingComponent";
import {isActive} from "@/app/helpers/isActive.helper";

import {Button, IconButton} from "../../../mTailwind/tailwindMaterial";

export default function UsersPage() {
  const [users, setUsers] = useState<ListUserReduced[]>([]);
  const [activeButton, setActiveButton] = useState("");
  const [loading, setLoading] = useState(true);

  const [totalPages, setTotalPages] = useState(1);
  const [currentPage, setCurrentPage] = useState(1);

  const pages = Array.from({length: totalPages}, (_, index) => index + 1);

  useEffect(() => {
    fetchUsersData(currentPage);
  }, [currentPage]);

  const fetchUsersData = async (page?: number) => {
    try {
      setActiveButton("");
      const response = await fetch(`/api/user?page=${page}`);
      const usersBd = (await response.json()) as UserListResponse;

      setUsers(usersBd.results);
      setTotalPages(usersBd.totalPages);
    } catch (error) {
      // eslint-disable-next-line no-console
      console.log(error);
    } finally {
      setLoading(false);
    }
  };

  const handleButtonClick = async (buttonText: string) => {
    setActiveButton(buttonText);
    setCurrentPage(1);
    const response = await fetch(`/api/user?filter=filter`);
    const data = (await response.json()) as UserListResponse;

    if ("error" in data) return;

    if (buttonText === "Active") {
      const usersActives: ListUserReduced[] = data.results.filter((user) => {
        if (isActive(user.day_of_payment)) return user;
      });

      setUsers(usersActives);
      setTotalPages(1);
    }

    if (buttonText === "Inactive") {
      const usersInactives: ListUserReduced[] = data.results.filter((user) => {
        if (!isActive(user.day_of_payment)) return user;
      });

      setUsers(usersInactives);
      setTotalPages(1);
    }
    if (buttonText === "All") {
      setUsers(data.results);
      setTotalPages(1);
    }
  };

  const searchHandler = async (search?: string) => {
    const response = await fetch(`/api/user?search=${search}`);
    const data = (await response.json()) as ResponseOk<ListUserReduced>;

    if ("error" in data) return;
    setUsers(data.results);
  };

  const getItemProps = (index: number) =>
    // eslint-disable-next-line @typescript-eslint/no-unsafe-return
    ({
      variant: currentPage === index ? "filled" : "text",
      color: "white",
      onClick: () => setCurrentPage(index),
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    }) as any;

  const next = () => {
    if (currentPage === totalPages) return;

    setCurrentPage(currentPage + 1);
  };

  const prev = () => {
    if (currentPage === 1) return;

    setCurrentPage(currentPage - 1);
  };

  return (
    <div className="w-full p-8">
      <div className="mb-6 flex items-center justify-between">
        <div className="flex space-x-2">
          <input
            className="rounded px-4 py-2"
            placeholder="Search user"
            onChange={(e) => searchHandler(e.target.value)}
          />
        </div>
        <div className="flex space-x-2">
          <UserStateButton
            isActive={activeButton === "Active"}
            selectColor={bgActiveColor}
            text="Active"
            textColor={textWithe}
            unselectColor={bgInactiveColor}
            onButtonClicked={() => handleButtonClick("Active")}
          />
          <UserStateButton
            isActive={activeButton === "Inactive"}
            selectColor={bgActiveColor}
            text="Inactive"
            textColor={textWithe}
            unselectColor={bgInactiveColor}
            onButtonClicked={() => handleButtonClick("Inactive")}
          />
          <UserStateButton
            isActive={activeButton === "All"}
            selectColor={bgActiveColor}
            text="All"
            textColor={textWithe}
            unselectColor={bgInactiveColor}
            onButtonClicked={() => handleButtonClick("All")}
          />
        </div>
      </div>
      <div className="overflow-hidden rounded-lg ">
        {loading ? <LoadingComponent loading /> : <ListTableUsers users={users} />}

        <div className="mb-4 mt-8 flex w-full justify-center">
          <div className="flex items-center gap-4">
            <Button
              className="flex items-center gap-2"
              color="white"
              disabled={currentPage === 1 || activeButton !== ""}
              variant="text"
              onClick={prev}
            >
              <ArrowLeftIcon className="h-4 w-4" strokeWidth={2} /> Previous
            </Button>

            <div className="flex items-center gap-2">
              {pages.map((page) => {
                return (
                  <IconButton key={page} {...getItemProps(page)} disabled={activeButton !== ""}>
                    {page}
                  </IconButton>
                );
              })}
            </div>
            <Button
              className="flex items-center gap-2"
              color="white"
              disabled={currentPage === totalPages || activeButton !== ""}
              variant="text"
              onClick={next}
            >
              Next
              <ArrowRightIcon className="h-4 w-4" strokeWidth={2} />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
