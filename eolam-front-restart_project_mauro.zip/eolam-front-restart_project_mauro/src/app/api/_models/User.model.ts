import type {Document} from "mongoose";
import type {InVideo} from "./Video.model";

import mongoose, {Schema} from "mongoose";

// Definimos una interfaz para el reporte de ejercicio
export interface InReport extends Document {
  _id: string;
  series: number;
  left_weight?: number;
  right_weight?: number;
  single_weight?: number;
  interval: number;
  comment_user?: string;
  rpe: "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "10";
  day: Date;
}

// Interfaz para un ejercicio
export interface InExercise extends Document {
  _id: string;
  video: InVideo;
  name_exercise: string;
  link: string;
  series: number;
  repetition_type: "TIME" | "AMOUNT";
  repetition: number;
  training_stage: {value: "MOVILITY" | "ACTIVATION" | "STRONG"; label: string};
  check_side: boolean;
  left_weight?: number;
  right_weight?: number;
  single_weight?: number;
  interval: number;
  comment_admin?: string;
  report: InReport;
}

// Interfaz para un día de entrenamiento
export interface InDay extends Document {
  _id: string;
  exercises: InExercise[];
}

// Interfaz para una semana de entrenamiento
export interface InWeek extends Document {
  week_number: number;
  amount_training_per_week: number;
  days: InDay[];
}

// Interfaz para el usuario
export interface InUser extends Document {
  is_admin: boolean;
  email: string;
  password: string;
  first_name: string;
  last_name: string;
  birthday: string;
  number_trainning_week: number;
  gym_name: string;
  day_of_payment: string;
  goals: string;
  last_training_day: string;
  training_place: string;
  weeks: InWeek[];
}

// Definición del esquema de reporte
const reportSchema: Schema = new Schema({
  _id: {type: String, required: true},
  name_exercise: {type: String, required: true},
  link: {type: String, required: true},
  series: {type: Number, required: true},
  repetition_type: {type: String, required: true},
  training_stage: {type: String, required: true},
  check_side: {type: Boolean, required: true},
  left_weight: {type: Number, required: true},
  right_weight: {type: Number, required: true},
  single_weight: {type: Number, required: true},
  interval: {type: Number, required: true},
  comment_user: {type: String},
  rpe: {type: String, enum: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"], required: true},
});

// Definición del esquema de ejercicio
const exerciseSchema: Schema = new Schema({
  _id: {type: String, required: true},
  name_exercise: {type: String, required: true},
  link: {type: String, required: true},
  series: {type: Number, required: true},
  repetition_type: {type: String, enum: ["TIME", "AMOUNT"], required: true},
  repetition: {type: Number, required: true},
  training_stage: {type: String, enum: ["MOVILITY", "ACTIVATION", "STRONG"], required: true},
  check_side: {type: Boolean, required: true},
  left_weight: {type: Number, required: true},
  right_weight: {type: Number, required: true},
  single_weight: {type: Number, required: true},
  interval: {type: Number, required: true},
  comment_admin: {type: String},
  report: {type: reportSchema, required: true},
});

// Definición del esquema de día
const daySchema: Schema = new Schema({
  _id: {type: String, required: true},
  exercises: {type: [exerciseSchema], required: true},
});

// Definición del esquema de semana
const weekSchema: Schema = new Schema({
  week_number: {type: Number, required: true},
  amount_training_per_week: {type: Number, required: true},
  days: {type: [daySchema], required: true},
});

// Definición del esquema de usuario
const userSchema: Schema = new Schema({
  is_admin: {type: Boolean, required: true},
  email: {type: String, required: true, unique: true},
  password: {type: String, required: true},
  first_name: {type: String, required: true},
  last_name: {type: String, required: true},
  birthday: {type: String, required: true},
  number_trainning_week: {type: Number, required: true},
  gym_name: {type: String, required: true},
  day_of_payment: {type: String, required: true},
  goals: {type: String, required: true},
  last_training_day: {type: String, required: true},
  training_place: {type: String, required: true},
  weeks: {type: [weekSchema], required: true},
});

// eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
export const UserModel = mongoose.models.User || mongoose.model<InUser>("User", userSchema);
