import type {Document} from "mongoose";

import mongoose, {Schema} from "mongoose";

// Definimos una interfaz para el ejercicio
export interface InVideo extends Document {
  value: {id: string; name: string; url: string};
  label: string;
}

// Definición del esquema de ejercicio
const videoSchema: Schema = new Schema({
  name: {type: String, required: true},
  url: {type: String, required: true},
});

// Exportamos el modelo
// eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
export const VideoModel = mongoose.models.videos || mongoose.model("videos", videoSchema);
