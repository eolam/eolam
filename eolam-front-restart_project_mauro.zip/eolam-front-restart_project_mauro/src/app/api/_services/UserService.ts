import type {InUser} from "@/app/api/_models/User.model";
import type {ListUserReduced} from "@/interfaces/user.interfaces";
// import bcrypt from 'bcrypt';

import type {UserAuth} from "@/utils/fetchAuth.utils";

import jwt from "jsonwebtoken";

import {UserModel} from "@/app/api/_models/User.model";
import {connectToDatabase} from "@/app/lib/db";
// import { hashPassword } from "@/utils/hash";

// Función asíncrona para obtener todos los tipos de ejercicios
export const getAllUsers = async (page = 1, limit = 10): Promise<UserListResponse> => {
  try {
    const users = (await UserModel.find().sort({first_name: 1})) as ListUserReduced[];
    const totalItems = await UserModel.countDocuments();

    return {
      message: "Reduced list users",
      results: users,
      totalItems,
      totalPages: Math.ceil(totalItems / limit),
      code: 200,
    };
  } catch (error) {
    console.error("Error al obtener los usuarios:", error);
    throw error;
  }
};

export const getUserById = async (id: string): Promise<InUser | undefined | null> => {
  try {
    return await UserModel.findById(id);
  } catch (error) {
    console.error("Error al obtener el usuario", error);
  }
};

/**
 * Returns User list reduced
 */
export interface UserListResponse {
  message: string;
  results: ListUserReduced[];
  totalItems: number;
  totalPages: number;
  code: number;
}

export const getUserListReduced = async (
  page = 1,
  limit = 10,
  search = "",
): Promise<UserListResponse> => {
  try {
    // Create search query
    const searchQuery = search
      ? {
          $or: [
            {first_name: {$regex: search, $options: "i"}},
            {last_name: {$regex: search, $options: "i"}},
          ],
        }
      : {};

    // Get total count for pagination
    const totalItems = await UserModel.countDocuments(searchQuery);

    // Get paginated results
    const users: ListUserReduced[] = (await UserModel.find(searchQuery)
      .select({
        is_admin: 1,
        email: 1,
        first_name: 1,
        last_name: 1,
        gym_name: 1,
        day_of_payment: 1,
        goals: 1,
        last_training_day: 1,
        _id: 1,
      })
      .sort({first_name: 1})
      .skip((page - 1) * limit)
      .limit(limit)) as ListUserReduced[];

    return {
      message: "Reduced list users",
      results: users,
      totalItems,
      totalPages: Math.ceil(totalItems / limit),
      code: 200,
    };
  } catch (error) {
    console.error("Error getting reduced user list:", error);
    throw error;
  }
};

export const getUserByEmail = async (email: string): Promise<InUser | undefined | null> => {
  try {
    await connectToDatabase();
    const user = await UserModel.findOne({email});

    return user;
  } catch (error) {
    console.error("Error al obtener el usuario", error);
    throw error;
  }
};

interface IUserData {
  email: string;
  first_name: string;
  password: string; // Contraseña hasheada.
}

interface LoginResponse {
  message?: string;
  user?: Omit<IUserData, "password">; // Devuelve todo menos la contraseña.
  error?: string;
  status: number;
}

export const loginController = async (email: string, password: string): Promise<UserAuth> => {
  // Obtener el usuario de la base de datos
  const user = await getUserByEmail(email);

  if (!user) {
    const error: UserAuth = {
      message: "Usuario no encontrado",
      status: 404,
    };

    return error;
  }

  if (user && user.is_admin) {
    const isPasswordValid = password === user.password ? true : false;

    // Verificar la contraseña
    // const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      const error: UserAuth = {
        message: "Contraseña incorrecta",
        status: 401,
      };

      return error;
    }

    const token = jwt.sign(
      {
        name: user.first_name,
        last_name: user.last_name,
        birthday: user.birthday,
        is_admin: user.is_admin,
        email: user.email,
      },
      process.env.NEXTAUTH_SECRET || "EOLAM",
      {expiresIn: "1h"},
    );

    // Respuesta exitosa
    return {
      name: user.first_name,
      last_name: user.last_name,
      birthday: user.birthday,
      is_admin: user.is_admin,
      id: user.id,
      email: user.email,
      token: token,
      message: "Login exitoso",
      status: 200,
      // user: { email: user.email, first_name: user.first_name },
    };
  }

  return {
    message: "Usuario no es administrador",
    status: 401,
  };
};
