import type {InVideo} from "../_models/Video.model";

import {VideoModel} from "../_models/Video.model";

export const getAllVideos = async (): Promise<InVideo[]> => {
  try {
    return await VideoModel.find();
  } catch (error) {
    console.error("Error al obtener los tipos de ejercicios:", error);
    throw error; // Puedes manejar el error según tus necesidades
  }
};
