import type {NextAuthOptions} from "next-auth";

declare module "next-auth" {
  interface Session {
    user?: {
      name?: string | null;
      email?: string | null;
      image?: string | null;
      isAuthorized?: boolean;
    };
  }
}

import GoogleProvider from "next-auth/providers/google";

import {getUserByEmail} from "../../_services/UserService";
import {getUserByEmail} from "../../_services/UserService";

export const authOptions: NextAuthOptions = {
  session: {
    strategy: "jwt",
  },
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
      authorization: {
        params: {
          prompt: "consent",
          access_type: "offline",
          response_type: "code",
        },
        url: process.env.NEXTAUTH_URL,
      },
    }),
  ],

  callbacks: {
    // 1. Maneja el inicio de sesión
    async signIn({user, account, profile}) {
      const email = user.email || "";

      const response = await getUserByEmail(email);

      if (response && response.is_admin) {
        return true;
      }

      return false;
    },
    // async session({session, token}) {
    //   try {
    //     if (session.user) {
    //       const email = session.user.email || "";
    //       const response = await getUserByEmail(email);

    //       if (!response || !response.is_admin) {
    //         session.user.isAuthorized = false;
    //       } else {
    //         session.user.isAuthorized = true;
    //       }
    //     }
    //     return session;
    //   } catch (error) {
    // 	console.error("Error in session callback:", error);
    //     return session;
    //   }
    // },
    async redirect({url, baseUrl}) {
      return url.startsWith(baseUrl) ? process.env.BASE_URL! : baseUrl;
    },
    async jwt({token}) {
      return token;
    },
  },
};
