import type {NextApiRequest, NextApiResponse} from "next";
// import { RequestHandler, Request, Response } from 'express';
type NextApiRequestWithFormData = NextApiRequest &
  Request & {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    files: any[];
  };

type NextApiResponseCustom = NextApiResponse & Response;
import NextAuth from "next-auth";

import {authOptions} from "@/app/api/auth/[...nextauth]/authOptions";

const handler = (req: NextApiRequestWithFormData, res: NextApiResponseCustom) =>
  // eslint-disable-next-line @typescript-eslint/no-unsafe-return
  NextAuth(req, res, authOptions);

export {handler as GET, handler as POST};
