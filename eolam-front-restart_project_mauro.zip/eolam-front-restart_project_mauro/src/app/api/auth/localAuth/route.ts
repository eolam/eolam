import { loginController } from "../../_services/UserService";

export async function POST(req: Request): Promise<Response> {
    try {
        // Parsear los datos enviados por el cliente
        const { email, password } = await req.json();
		console.log('Entro al nuevo controller');
        // Validar que los campos no estén vacíos
        if (!email || !password) {
            return new Response(
                JSON.stringify({ error: 'Email y contraseña son obligatorios' }),
                { status: 400 }
            );
        }

        // Llamar al controlador para manejar la lógica
        const response = await loginController(email, password);

        if (!response) {
			throw new Error('Error en el login');
        }

        return new Response(JSON.stringify(response), { status: 200 });
    } catch (err) {
        console.error('Error en el login:', err);
        return new Response(
            JSON.stringify({ error: 'Error interno del servidor' }),
            { status: 500 }
        );
    }
}
