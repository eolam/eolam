import {NextResponse} from "next/server";

import {connectToDatabase} from "@/app/lib/db";
import { UserModel } from "@/app/api/_models/User.model";



export async function POST(request: Request) {
  try {
    const { id_week } = await request.json();
    
    await connectToDatabase();

    // Find the user and update the specific week and day
    const result = await UserModel.updateOne(
      { 
        "weeks.week_number": id_week,
        "weeks.days.date": null 
      },
      { 
        $push: {
          "weeks.$[week].days.$[day].exercises": exercise
        }
      },
      {
        arrayFilters: [
          { "week.week_number": id_week },
          { "day.date": date }
        ]
      }
    );

  console.log("id_week", id_week);

  return NextResponse.json({message: "Hello, world!", id_week});
}
