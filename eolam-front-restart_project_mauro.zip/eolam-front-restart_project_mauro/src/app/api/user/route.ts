import {NextResponse} from "next/server";

import {connectToDatabase} from "@/app/lib/db";
import {getAllUsers, getUserListReduced} from "@/app/api/_services/UserService";

export async function GET(request: Request) {
  try {
    await connectToDatabase();

    // Obtener parámetros de búsqueda de la URL
    const {searchParams} = new URL(request.url);
    const search = searchParams.get("search") || "";
    const page = parseInt(searchParams.get("page") || "1");
    const filter = searchParams.get("filter") || "";

    console.log(filter);

    let response;

    if (filter === "filter") {
      response = await getAllUsers(page, 10);
    } else {
      response = await getUserListReduced(page, 10, search);
    }

    return NextResponse.json(response, {status: 200});
  } catch (error) {
    console.error("Error fetching users:", error);

    return NextResponse.json({message: "Internal Server Error"}, {status: 500});
  }
}
