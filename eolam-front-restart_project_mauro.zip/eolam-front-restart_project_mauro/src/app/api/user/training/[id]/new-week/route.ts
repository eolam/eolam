import type {InUser} from "@/app/api/_models/User.model";

import {NextResponse} from "next/server";

import {connectToDatabase} from "@/app/lib/db";
import {UserModel} from "@/app/api/_models/User.model";

export async function POST(request: Request, {params}: {params: {id: string}}) {
  try {
    await connectToDatabase();

    const user: InUser | null = await UserModel.findById(params.id);

    if (!user) {
      return NextResponse.json({message: "User not found"}, {status: 404});
    }

    const weeks = user.weeks;

    const updatedUser: InUser | null = await UserModel.findByIdAndUpdate(
      params.id,
      {
        $push: {
          weeks: {
            week_number: weeks.length + 1,
            amount_training_per_week: weeks[weeks.length - 1].amount_training_per_week,
            days: [],
          },
        },
      },
      {new: true},
    );

    return NextResponse.json(updatedUser, {status: 200});
  } catch (error) {
    console.error("Error fetching user:", error);

    return NextResponse.json({message: "Internal Server Error"}, {status: 500});
  }
}
