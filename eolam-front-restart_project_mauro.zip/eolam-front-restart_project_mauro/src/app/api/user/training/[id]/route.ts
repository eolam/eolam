import type {NewTrainingBody} from "@/interfaces/training.interface";
import type {User} from "@/interfaces/user.interfaces";
import type {InUser} from "@/app/api/_models/User.model";

import {NextResponse} from "next/server";
import mongoose from "mongoose";

import {connectToDatabase} from "@/app/lib/db";
import {UserModel} from "@/app/api/_models/User.model";

export async function GET(request: Request, {params}: {params: {id: string}}) {
  try {
    await connectToDatabase();

    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    const user = await UserModel.findOne({_id: params.id});

    if (!user) {
      return NextResponse.json({message: "User not found"}, {status: 404});
    }

    // Devolvemos el usuario completo con todos sus datos, incluyendo el historial de entrenamiento
    return NextResponse.json(user, {status: 200});
  } catch (error) {
    console.error("Error fetching user training history:", error);

    return NextResponse.json({message: "Internal Server Error"}, {status: 500});
  }
}

export async function POST(request: Request, {params}: {params: {id: string}}) {
  const url = new URL(request.url);
  const index_week = url.searchParams.get("index_week");

  if (index_week) {
    try {
      await connectToDatabase();
      const {id} = params;

      const _id = new mongoose.Types.ObjectId().toString();

      const user: InUser | null = await UserModel.findOneAndUpdate(
        {_id: id},
        {
          $push: {
            [`weeks.${index_week - 1}.days`]: {
              _id: _id,
              exercises: [],
            },
          },
        },
      );

      return NextResponse.json(user, {status: 201});
    } catch (error) {
      console.error("Error saving exercise:", error);

      return NextResponse.json({message: "Internal Server Error"}, {status: 500});
    }
  } else {
    try {
      await connectToDatabase();

      const exerciseData = (await request.json()) as NewTrainingBody;
      const {
        index_week,
        index_day,
        video,
        stage,
        repetition_type,
        series,
        check_side,
        repetition,
        left_weight,
        right_weight,
        single_weight,
        interval,
        comment,
      } = exerciseData;
      const _id = new mongoose.Types.ObjectId().toString();

      // Buscar y actualizar el usuario
      const result: User | null = await UserModel.findOneAndUpdate(
        {
          _id: params.id,
        },
        {
          $push: {
            [`weeks.${index_week}.days.${index_day}.exercises`]: {
              _id: _id,
              name_exercise: video.value.name,
              link: video.value.url,
              training_stage: stage.value,
              repetition_type: repetition_type === true ? "TIME" : "AMOUNT",
              series: series,
              repetition: repetition,
              check_side: check_side,
              left_weight: left_weight ?? undefined,
              right_weight: right_weight ?? undefined,
              single_weight: single_weight ?? undefined,
              interval: interval,
              comment_admin: comment ?? undefined,
              report: {},
            },
          },
        },
        {new: true, upsert: true},
      );

      if (!result) {
        return NextResponse.json({message: "User, week or day not found"}, {status: 404});
      }

      return NextResponse.json(result, {status: 201});
    } catch (error) {
      console.error("Error saving exercise:", error);

      return NextResponse.json({message: "Internal Server Error"}, {status: 500});
    }
  }
}

export async function PUT(request: Request) {
  const exerciseData = (await request.json()) as NewTrainingBody;

  console.log("exerciseData", exerciseData);

  const {
    id,
    id_exercise,
    index_week,
    index_day,
    video,
    stage,
    repetition_type,
    series,
    repetition,
    check_side,
    left_weight,
    right_weight,
    single_weight,
    interval,
    comment,
  } = exerciseData;

  try {
    const result: User | null = await UserModel.findOneAndUpdate(
      {
        _id: id,
        [`weeks.${index_week}.days.${index_day}.exercises._id`]: id_exercise,
      },
      {
        $set: {
          [`weeks.${index_week}.days.${index_day}.exercises.$`]: {
            _id: id_exercise,
            name_exercise: video.value.name,
            link: video.value.url,
            training_stage: stage.value,
            repetition_type: repetition_type === true ? "TIME" : "AMOUNT",
            series: series,
            repetition: repetition,
            check_side: check_side,
            left_weight: left_weight ?? undefined,
            right_weight: right_weight ?? undefined,
            single_weight: single_weight ?? undefined,
            interval: interval,
            comment_admin: comment ?? undefined,
            report: {},
          },
        },
      },
      {new: true},
    );

    console.log(
      "result",
      result?.weeks[index_week].days[index_day].exercises[
        result.weeks[index_week].days[index_day].exercises.length - 1
      ],
    );

    return NextResponse.json(result, {status: 201});
  } catch (error) {
    console.error("Error updating exercise:", error);

    return NextResponse.json({message: "Internal Server Error"}, {status: 500});
  }
}
