import {NextResponse} from "next/server";

import {connectToDatabase} from "@/app/lib/db";
import {getAllVideos} from "@/app/api/_services/VideoService";

export async function GET() {
  try {
    connectToDatabase();

    // Espera a que se resuelva la llamada asíncrona
    const res = await getAllVideos();

    return NextResponse.json(
      {
        message: res,
      },
      {status: 200},
    );
  } catch (error) {
    console.error("Error fetching exercises:", error);

    return NextResponse.json(
      {
        message: "Failed to fetch exercises",
      },
      {status: 500},
    );
  }
}
