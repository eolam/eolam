/* eslint-disable no-console */
import type {RequestInit} from "next/dist/server/web/spec-extension/request";
import type {ResponseError} from "@/interfaces/error.interface";

import {CustomError} from "@/utils/Errors/CustomError";

export async function fetchJSON<T>(url: string, options?: RequestInit): Promise<T | ResponseError> {
  try {
    const resp = await fetch(url, options);

    if (!resp.ok) {
      throw new CustomError(`HTTP error! status: ${resp.status}`, resp.status, true);
    }
    const json = (await resp.json()) as T;

    return json;
  } catch (error) {
    const err = error as CustomError;

    const newError: ResponseError = {
      message: err.message,
      code: err.code,
      error: err.error,
      results: null,
      data: null,
    };

    return newError;
  }
}
