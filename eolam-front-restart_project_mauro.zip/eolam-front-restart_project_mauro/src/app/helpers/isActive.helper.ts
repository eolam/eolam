/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import dayjs from "dayjs";

export const isActive = (paymentDay: string): boolean => {
  const currentDate = dayjs();
  const lastPaymentDate = dayjs(paymentDay);

  // eslint-disable-next-line @typescript-eslint/no-unsafe-member-access
  const diffInDays = currentDate.diff(lastPaymentDate, "day");

  return diffInDays <= 30;
};
