import "../assets/styles/global.css";
import AuthProvider from "@/providers/AuthProvider";

export default function LoginLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body className="background-pattern flex min-h-screen flex-col items-center">
        <AuthProvider>
          <main className="h-full w-full">{children}</main>
          <footer className="pt-5 text-center opacity-70">
            © {new Date().getFullYear()} Eolam | All rights reserved
          </footer>
        </AuthProvider>
      </body>
    </html>
  );
}
