// lib/db.ts
import mongoose, {ConnectionStates} from "mongoose";

const MONGODB_URI = process.env.MONGODB_URI;

export async function connectToDatabase() {
  if (mongoose.connection.readyState >= ConnectionStates.connected) {
    return;
  }

  if (MONGODB_URI?.length) await mongoose.connect(MONGODB_URI);
}
