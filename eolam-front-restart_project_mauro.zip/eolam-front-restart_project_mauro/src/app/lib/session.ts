import "server-only";
import type {JWTPayload} from "jose";
import type {User} from "next-auth";
import type {ResponseOk} from "@/interfaces/response.interface";
import type {UserEmail} from "@/interfaces/user.interfaces";

import {cookies} from "next/headers";
import {redirect} from "next/navigation";
import {SignJWT, jwtVerify} from "jose";
import {cache} from "react";

import {baseUrl} from "@/utils/route.util";

import {fetchJSON} from "../helpers/fetch.helper";

const key = new TextEncoder().encode(process.env.SECRET);

const sameSiteOption: "lax" | "strict" | "none" | undefined = "lax";

export const cookie = {
  name: "session",
  options: {httpOnly: true, secure: true, sameSite: sameSiteOption, path: "/"},
  duration: 24 * 60 * 60 * 1000, //24hs
};

const encrypt = async (payload: JWTPayload) => {
  return new SignJWT(payload)
    .setProtectedHeader({alg: "HS256"})
    .setIssuedAt()
    .setExpirationTime("1day")
    .sign(key);
};

const decrypt = async (session: string) => {
  try {
    const {payload} = await jwtVerify(session, key, {
      algorithms: ["HS256"],
    });

    return payload;
  } catch (error) {
    return null;
  }
};

export const createSession = async (userEmail: string) => {
  const expires = new Date(Date.now() + cookie.duration);
  const session = await encrypt({email: userEmail, expires});

  cookies().set(cookie.name, session, {...cookie.options, expires});
  redirect("/admin-dashboard");
};

export const verifySession = async () => {
  const currentCookie = cookies().get(cookie.name)?.value;
  const session = currentCookie && (await decrypt(currentCookie));

  if (!session) return redirect("/");

  const objUserEmail: UserEmail = {
    userEmail: session.email as string,
  };

  return objUserEmail;
};

export const deleteSession = () => {
  cookies().delete(cookie.name);
  redirect("/");
};

const route = `${baseUrl}/user`;

export async function cachedGetUserSession() {
  return cache(async () => {
    const session: UserEmail = await verifySession();

    const response = await fetchJSON<ResponseOk<User>>(`${route}/${session.userEmail}`);

    return response;
  });
}
