"use client";
import {useRouter} from "next/navigation";
import {FaExclamationTriangle} from "react-icons/fa";

import {buttonColorSecondary, textWithe} from "@/assets/styles/colors";

export default function NotFound() {
  const router = useRouter();

  return (
    <section className="h-screen flex-grow">
      <div className="container m-auto w-4/12 py-24">
        <div className="rounded-md border bg-white  px-6 py-8 shadow-md  md:m-0">
          <div className="flex justify-center">
            <FaExclamationTriangle className="fas fa-exclamation-triangle text-6xl text-yellow-400" />
          </div>
          <div className="text-center">
            <h1 className="mb-2 mt-4 text-3xl font-bold text-black">Page Not Found</h1>
            <p className="mb-10 text-xl text-gray-500">
              The page you are looking for does not exist.
            </p>
            <div className="flex justify-center text-center">
              <button
                className={`${buttonColorSecondary} ${textWithe} w-6/12 rounded p-4 shadow hover:bg-pink-800 `}
                type="button"
                onClick={async () => {
                  router.push("/");
                }}
              >
                <p>Go Home</p>
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className="flex-grow" />
    </section>
  );
}
