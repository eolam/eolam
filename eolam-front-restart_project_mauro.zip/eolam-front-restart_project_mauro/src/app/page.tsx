import Link from "next/link";

import GoogleButtonAuth from "@/components/GoogleButtonAuth";

import "../assets/styles/global.css";
import SignupForm from "../components/SignupForm.component";

function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="w-96 bg-white bg-opacity-20 p-10 shadow-lg">
        <h1 className="mb-6 text-center text-2xl font-semibold">AM Entrenamiento Online</h1>
        <div className="space-y-4">
          <SignupForm />
          <GoogleButtonAuth />
          <Link className="block text-center text-sm text-gray-800" href="#">
            Forgot password?
          </Link>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
