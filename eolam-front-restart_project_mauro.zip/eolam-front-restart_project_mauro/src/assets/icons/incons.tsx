export const arrowBack =
  "https://cdn.builder.io/api/v1/image/assets/TEMP/40b6dbf1f2131aeaac2184fb0cb5a653d3eb711dde40cdbec6ec4ecc5dda093b?";

export const logoutIcon =
  "https://cdn.builder.io/api/v1/image/assets/TEMP/d99d574040d2e37c2c2d790d5e6c98de17e36d3cf9911d5774ae429e759fcfbc?";
