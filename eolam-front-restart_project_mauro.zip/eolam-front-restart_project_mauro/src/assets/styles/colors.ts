//Button
export const buttonColorSecondary = "bg-pink-500";

export const hoverColor = "bg-pink-800";

export const bgInactiveColor = "bg-gray-800";

export const bgActiveColor = "bg-pink-600";

//Text
export const textGray400 = "text-gray-400";

export const textWithe = "text-white";

//Bg
export const bgAppDark = "bg-gray-900";

export const bgTables = "bg-gray-700";
