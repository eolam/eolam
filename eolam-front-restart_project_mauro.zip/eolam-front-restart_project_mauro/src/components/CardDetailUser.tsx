/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import type {InUser} from "@/app/api/_models/User.model";
// import type {FormFieldsWeek} from "@/interfaces/week.interface";
// import type {FieldValues} from "react-hook-form";

// import {useForm, Controller} from "react-hook-form";
// import {useRouter} from "next/navigation";
import {useEffect, useState} from "react";
import {PiMagicWand} from "react-icons/pi";

import {
  bgActiveColor,
  bgInactiveColor,
  bgTables,
  buttonColorSecondary,
  hoverColor,
  textWithe,
} from "@/assets/styles/colors";
import {isActive} from "@/app/helpers/isActive.helper";
// import {postNewWeek} from "@/utils/fetchWeek.utils";
// import {postNewExercise} from "@/utils/fetchReport.util";

// import {Button, Dialog, DialogBody} from "../mTailwind/tailwindMaterial";

export default function CardDetailUser({id}: {id: string | string[]}) {
  const [user, setUser] = useState<InUser>();

  useEffect(() => {
    const fetchUserData = async () => {
      try {
        const response = await fetch(`/api/user/${id}`);
        const userBd = (await response.json()) as InUser;

        if ("error" in response) return;
        setUser(userBd);

        localStorage.setItem("_id", Array.isArray(id) ? id[0] : id);
      } catch (error) {
        // eslint-disable-next-line no-console
        console.log(error);
      }
    };

    fetchUserData();
  }, []);

  const handleNewWeek = async () => {
    const response = await fetch(`/api/user/training/${id}/new-week`, {
      method: "POST",
    });
    const userBd = await response.json();

    setUser(userBd);
    window.location.reload();
  };

  if (!user) return null; // Add this line for safety user is undefined

  const {first_name, last_name, day_of_payment, last_training_day, goals, training_place} = user;

  return (
    <div className={`${bgTables} m-2.5 h-min w-3/6 rounded-lg text-white`}>
      <div className="rounded-t-lg bg-pink-700 pb-2 pt-2 text-center">Informacion Personal</div>
      <div className="divide-y divide-gray-200 p-3 px-7">
        <div>
          <div className="flex content-center  justify-between text-center ">
            <div className="mb-4 border-b text-center font-semibold ">
              {first_name} {last_name}
            </div>
            <div className=" mb-4 content-center  pb-1 ">
              <span
                className={`block h-3 w-3 ${isActive(day_of_payment) ? bgActiveColor : bgInactiveColor}  rounded-full`}
              />
            </div>
          </div>

          <div className="mb-2 flex  content-center justify-between text-center">
            Ultimo pago: <span>{day_of_payment}</span>
          </div>
          <div className="mb-2 flex  content-center justify-between text-center ">
            Ultimo entrenamiento: <span>{last_training_day}</span>
          </div>
          <div className="flex content-center text-center">Objetivos:</div>
          <div className="mb-4 ml-5">{goals}</div>
          <div className="flex content-center  justify-between text-center">
            GYM: <span>{training_place}</span>
          </div>
        </div>
      </div>
      <div className="flex justify-center">
        <button
          className={`${buttonColorSecondary} ${textWithe} mb-5 mt-3 flex rounded p-1  text-center shadow hover:${hoverColor} rounded-sm`}
          type="button"
          onClick={() => handleNewWeek()}
        >
          <div className="ml-4 mr-4">
            <p>+ Nueva semana</p>
          </div>
        </button>
      </div>
    </div>
  );
}
