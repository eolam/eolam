"use client";

import type {FormFieldsMethods, MethodIdSelect} from "@/interfaces/paymentMethod.interface";
import type {PaymentMethod} from "../interfaces/paymentMethod.interface";

import {Controller, useForm} from "react-hook-form";
import {useSession} from "next-auth/react";
import {useEffect, useState} from "react";
import Select from "react-select";

import {getUserByUsername} from "@/utils/fetchUsers";
import {isResponseOk} from "@/interfaces/response.interface";
import {updatePaymentMethod} from "@/utils/fetchPaymentMethod.util";

import {
  Button,
  Card,
  CardBody,
  CardFooter,
  CardHeader,
  Typography,
} from "../mTailwind/tailwindMaterial";

import {InputField} from "./FormComponents/InputField";

export default function CardMyProfile({sessionUserCookie}: {sessionUserCookie?: string}) {
  const {control, handleSubmit, setValue} = useForm<FormFieldsMethods>({});
  const {data} = useSession();
  const id = Date.now().toString();
  const [sessionUser, setSessionUser] = useState<string>("");
  const [username, setUsername] = useState<string>("");
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>();

  useEffect(() => {
    if (data && "user" in data) {
      data.user?.email && setSessionUser(data.user.email);
    } else {
      sessionUserCookie && setSessionUser(sessionUserCookie);
    }
  }, [data, sessionUser, sessionUserCookie]);

  useEffect(() => {
    const loadUser = async () => {
      const userData = await getUserByUsername(sessionUser);

      if (isResponseOk(userData)) {
        const methods = userData.data[0].paymentMethods;

        setUsername(`${userData.data[0].name} ${userData.data[0].last_name}`);

        if (Array.isArray(methods)) {
          setPaymentMethods(methods);
        } else {
          setPaymentMethods(undefined);
        }
      }
    };

    loadUser();
  }, [sessionUser]);

  const updateMethod = async (data: FormFieldsMethods) => {
    const {methodId, newData}: {methodId: MethodIdSelect; newData: string} = data;

    const updateResponse = await updatePaymentMethod(methodId.value, {data: newData});

    if ("error" in updateResponse) {
      // eslint-disable-next-line no-console
      console.error("Error updating payment method:", updateResponse.message);
    } else {
      const userData = await getUserByUsername(sessionUser);

      if (isResponseOk(userData)) {
        const methods = userData.data[0].paymentMethods;

        setValue("newData", "");
        if (Array.isArray(methods)) {
          setPaymentMethods(methods);
        } else {
          setPaymentMethods(undefined);
        }
      }
    }
  };

  return (
    <div>
      <Card className="my-10 w-full p-8" color="gray" variant="gradient">
        <CardHeader
          className="m-0 mb-4 rounded-none border-b border-white/10 pb-4 text-center"
          color="transparent"
          floated={false}
          shadow={false}
        >
          <Typography className="font-normal uppercase" color="white" variant="small">
            {username}
          </Typography>
        </CardHeader>
        <CardBody className="p-0">
          <div>
            {paymentMethods?.map((method) => {
              return (
                <div key={method.id}>
                  <ul className="mt-4 flex flex-col">
                    <div className="flex w-full">
                      <div className="w-5/6">
                        <li className="mb-2 flex w-full items-center">{method.description}:</li>
                        <li className="mb-2 flex w-full items-center">{method.data}</li>
                      </div>
                    </div>
                  </ul>
                </div>
              );
            })}
          </div>
        </CardBody>
        <CardFooter>
          <form className="flex justify-center" onSubmit={handleSubmit(updateMethod)}>
            <div className="mt-4 flex flex-col">
              <div className="flex w-full">
                <div className="flex w-full items-center">
                  {paymentMethods ? (
                    <Controller
                      control={control}
                      name="methodId"
                      render={({field}) => (
                        <Select
                          {...field}
                          className="basic-single text-sm text-black"
                          classNamePrefix="select"
                          id={id}
                          isSearchable={false}
                          options={paymentMethods.map(
                            ({id, description}: {id: number; description: string}) => ({
                              options: [{value: id, label: description}],
                            }),
                          )}
                        />
                      )}
                    />
                  ) : null}
                </div>
                <div className="flex w-full items-center">
                  <InputField
                    control={control}
                    name="newData"
                    placeholder="update data to pay"
                    w="w-full"
                  />
                </div>
                <div className="mx-6 flex w-1/6 flex-col">
                  <div className="flex h-1/2"> </div>
                  <Button
                    fullWidth
                    className="flex items-center justify-center hover:scale-[1.02] focus:scale-[1.02] active:scale-100"
                    color="white"
                    ripple={false}
                    size="sm"
                    type="submit"
                  >
                    <span>Update</span>
                  </Button>
                </div>
              </div>
            </div>
          </form>
        </CardFooter>
      </Card>
    </div>
  );
}
