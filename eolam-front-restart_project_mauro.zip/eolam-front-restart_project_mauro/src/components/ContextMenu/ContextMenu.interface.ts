export interface ContextMenuProps {
  x: number;
  y: number;
  data: Data;
  closeContextMenu: () => void;
  onClickButton: (id: number) => Promise<void>;
  text: string;
}

export interface Data {
  number?: number;
  id: number;
  name?: string;
}
