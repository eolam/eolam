import type {FC} from "react";
import type {ContextMenuProps} from "./ContextMenu.interface";

import {useRef} from "react";

import {useOnClickOutside} from "@/utils/hooks/useOnClickOutside";

// eslint-disable-next-line react/function-component-definition
export const ContextMenu: FC<ContextMenuProps> = ({
  x,
  y,
  closeContextMenu,
  data,
  onClickButton,
  text,
}) => {
  const contextMenuRef = useRef<HTMLDivElement>(null);

  useOnClickOutside(contextMenuRef, closeContextMenu);

  return (
    <div
      ref={contextMenuRef}
      className="absolute z-20 rounded-b-md rounded-r-md border-none bg-cyan-50 px-3
    py-1 text-sm text-gray-800
    hover:cursor-pointer hover:bg-blue-gray-800
    hover:text-white"
      style={{top: `${y + 5}px`, left: `${x + 5}px`}}
      onClick={() => onClickButton(data.id)}
    >
      {text}
    </div>
  );
};
