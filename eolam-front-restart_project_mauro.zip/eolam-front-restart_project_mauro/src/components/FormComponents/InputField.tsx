import type {Control} from "react-hook-form";
import type {FormFieldsWeek} from "@/interfaces/week.interface";

import {Controller} from "react-hook-form";

export function InputField({
  name,
  control,
  placeholder,
  type = "text",
  disabled = false,
  w = "w-16",
}: {
  name: string;
  control: Control<FormFieldsWeek>;
  placeholder: string;
  type: string;
  disabled: boolean;
  w: string;
}) {
  return (
    <Controller
      control={control}
      name={name}
      render={({field}) => (
        <input
          {...field}
          className={`h-9 rounded-md  p-2 text-xs ${w} ${disabled ? "bg-gray-500 text-gray-600" : "bg-white text-black"}`}
          disabled={disabled}
          placeholder={placeholder}
          type={type}
          // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
          value={field.value ?? ""}
        />
      )}
    />
  );
}
