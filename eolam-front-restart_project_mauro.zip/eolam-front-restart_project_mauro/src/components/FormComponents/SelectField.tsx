import type {Control} from "react-hook-form";
import type {GroupBase, OptionsOrGroups} from "react-select";
import type {FormFieldsMethods} from "@/interfaces/paymentMethod.interface";
import type {SelectForm} from "@/utils/commonResourcesForms.util";
import type {FormFieldsWeek} from "@/interfaces/week.interface";

import {Controller} from "react-hook-form";
import Select from "react-select";

export function SelectField({
  name,
  control,
  options,
  isSearchable = true,
  id,
  defaultValue,
}: {
  name: string;
  control: Control<FormFieldsMethods | FormFieldsWeek>;
  options?: OptionsOrGroups<SelectForm, GroupBase<SelectForm>>;
  isSearchable: boolean;
  id: string;
  defaultValue?: string;
}) {
  return (
    <Controller
      control={control}
      defaultValue={defaultValue}
      name={name}
      render={({field}) => (
        <Select
          {...field}
          className="basic-single text-sm text-black"
          classNamePrefix="select"
          id={id}
          isSearchable={isSearchable}
          options={options?.map((op) =>
            "name" in op
              ? {options: [{value: op.id, label: op.name}]}
              : {options: [{value: "value" in op && op.value, label: op.label}]},
          )}
        />
      )}
    />
  );
}
