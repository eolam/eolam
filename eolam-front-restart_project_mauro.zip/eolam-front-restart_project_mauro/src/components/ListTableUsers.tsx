"use client";
import type {ListUserReduced} from "@/interfaces/user.interfaces";

import {useRouter} from "next/navigation";

import {isActive} from "@/app/helpers/isActive.helper";
import {bgActiveColor, bgInactiveColor, bgTables} from "@/assets/styles/colors";

export default function ListTableUsers({users}: {users: ListUserReduced[]}) {
  const router = useRouter();

  return (
    <div className="">
      <table className="max-h-full w-full ">
        <thead className="bg-pink-600 text-white">
          <tr>
            <th className="px-6 py-3 text-left">Name</th>
            <th className="px-6 py-3 text-left">Last name</th>
            <th className="px-6 py-3 text-left">Last training</th>
            <th className="px-6 py-3 text-left">Active</th>
          </tr>
        </thead>
        <tbody className={`${bgTables} divide-y divide-gray-600`}>
          {users.map(({first_name, last_name, last_training_day, day_of_payment, _id}) => {
            return (
              <tr
                key={_id}
                className="hover:bg-zinc-100 cursor-pointer hover:text-black"
                onClick={async () => {
                  router.push(`/admin-dashboard/users/${_id}`);
                }}
              >
                <td className="px-6 py-4">{first_name}</td>
                <td className="px-6 py-4">{last_name}</td>
                <td className="px-6 py-4">{last_training_day}</td>
                <td className="px-6 py-4">
                  <span
                    className={`block h-3 w-3 ${isActive(day_of_payment) ? bgActiveColor : bgInactiveColor}  rounded-full`}
                  />
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
