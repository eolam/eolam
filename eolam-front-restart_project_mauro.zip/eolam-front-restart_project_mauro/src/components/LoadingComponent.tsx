"use client";
import {BarLoader} from "react-spinners";

const override = {
  display: "block",
  margin: "100px auto",
};

export default function LoadingComponent({loading}: {loading: boolean}) {
  return (
    <BarLoader
      aria-label="Loading Spinner"
      color="#ffcddf"
      cssOverride={override}
      height={20}
      loading={loading}
      width={150}
    />
  );
}
