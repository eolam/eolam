import ButtonLogout from "./buttonLogout";
import ButtonBack from "./buttonBack";

export default function NavBar() {
  return (
    <div className="w-full bg-gray-100">
      <div className="flex items-center justify-between bg-pink-600 p-6 text-lg text-white">
        <ButtonBack />
        <span>AM Entrenamiento Online</span>
        <ButtonLogout />
      </div>
    </div>
  );
}
