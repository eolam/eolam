import type {Control, UseFormWatch} from "react-hook-form";
import type {FormFieldsMethods} from "@/utils/commonResourcesForms.util";
import type {ExerciseType} from "@/interfaces/exerciseType.interface";

import {useEffect, useState} from "react";
import {Controller, useForm} from "react-hook-form";

import {repetitionType} from "@/utils/commonResourcesForms.util";

import {
  Button,
  Dialog,
  DialogHeader,
  DialogBody,
  DialogFooter,
  Checkbox,
} from "../mTailwind/tailwindMaterial";

import {SelectField} from "./FormComponents/SelectField";
import {InputField} from "./FormComponents/InputField";

interface NewActivityModalProps {
  open: boolean;
  onClose: () => void;
  onSubmit: () => Promise<void>;
}

export function NewActivityModal({open, onClose, onSubmit}: NewActivityModalProps) {
  const [exercisesSelect, setExercisesSelect] = useState<ExerciseType[]>();
  const [isChecked, setIsChecked] = useState(true);
  const [isMounted, setIsMounted] = useState(false);

  const {control, handleSubmit, setValue, watch, reset} = useForm<FormFieldsMethods>({
    defaultValues: {
      id_exercise_type: null,
      id_repetition_type: null,
      series: null,
      check_side: true,
      repetition: null,
      left_weight: null,
      right_weight: null,
      single_weight: null,
      interval: null,
    },
  });

  useEffect(() => {
    setIsMounted(true);
    loadExercisesSelect();
  }, []);

  const loadExercisesSelect = async (search?: string) => {
    try {
      const response = await fetch("/api/video");
      const data = await response.json();

      if (!data.error) {
        setExercisesSelect(data.message);
      }
    } catch (error) {
      console.error("Error loading exercises:", error);
    }
  };

  const handleCheckboxChange = (checked: boolean) => {
    setIsChecked(checked);
    if (checked) {
      setValue("single_weight", null);
    } else {
      setValue("left_weight", null);
      setValue("right_weight", null);
    }
  };

  const exercise = watch("id_exercise_type");
  const repeType = watch("id_repetition_type");
  const repetition = watch("repetition");
  const series = watch("series");
  const isButtonSaveDisabled = !exercise || !repeType || !repetition || !series;

  return (
    <Dialog className="bg-gray-800 text-white" handler={onClose} open={open}>
      <DialogHeader>New exercise for user</DialogHeader>
      <DialogBody>
        <form className="w-full" onSubmit={handleSubmit(onSubmit)}>
          <div className="flex flex-col gap-4">
            {/* Exercise Select */}
            <div className="w-full">
              <label className="text-sm" htmlFor="exercise">
                Exercise
              </label>
              {isMounted ? (
                <SelectField
                  control={control}
                  id="exercise"
                  isSearchable={false}
                  name="id_exercise_type"
                  options={exercisesSelect}
                />
              ) : null}
            </div>

            {/* Rest of the form fields... */}
            {/* Copy the rest of the form fields from the original component */}
          </div>
        </form>
      </DialogBody>
      <DialogFooter>
        <Button className="mr-1" color="red" variant="text" onClick={onClose}>
          Cancel
        </Button>
        <Button
          color="green"
          disabled={isButtonSaveDisabled}
          variant="gradient"
          onClick={handleSubmit(onSubmit)}
        >
          Create
        </Button>
      </DialogFooter>
    </Dialog>
  );
}
