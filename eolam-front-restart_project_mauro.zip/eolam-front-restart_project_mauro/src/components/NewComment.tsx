/* eslint-disable react/no-unescaped-entities */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
import {useEffect, useState} from "react";
import {Controller, useForm} from "react-hook-form";

import {updateExerciseUser} from "@/utils/fetchExerciseUser.util";

import {Button, Dialog, DialogBody} from "../mTailwind/tailwindMaterial";

export default function NewComment({
  size = "",
  setSize,
  id_exercise,
  initialComment,
  exercise_name = "",
  loadTrainingExercises,
}: {
  size: string;
  setSize: () => void;
  id_exercise: number;
  initialComment: string;
  exercise_name: string;
  loadTrainingExercises: () => Promise<void>;
}) {
  const {control, handleSubmit, setValue} = useForm({});

  const [newComment, setNewComment] = useState("");

  const handleInputChange = (value: string) => {
    setNewComment(value);
  };

  const createNewComment = async () => {
    await updateExerciseUser(id_exercise, {comment_admin: newComment});
    await loadTrainingExercises();
  };

  useEffect(() => {
    setValue("comment_admin", initialComment);
  }, [initialComment, setValue]);

  return (
    <Dialog
      className="flex h-1/3 flex-col justify-center rounded-sm bg-blue-gray-900 "
      handler={setSize}
      open={size === "xs"}
      size="xs"
    >
      <DialogBody className="flex justify-center  text-base font-thin text-white">
        Add a comment to <span className="ml-2 font-bold"> "{exercise_name}" </span>
      </DialogBody>
      <div className="flex w-full justify-center">
        <form className="flex flex-col justify-center" onSubmit={handleSubmit(createNewComment)}>
          <div className="flex justify-center ">
            <Controller
              control={control}
              name="comment_admin"
              render={({field}) => (
                <div className="w-full">
                  <input
                    className="mx-2 h-16 w-72  rounded-sm border-b-cyan-100 bg-cyan-50 pl-2 text-sm text-black"
                    placeholder="Comment to the exercise..."
                    type="text"
                    {...field}
                    id="comment_admin"
                    value={field.value ?? ""}
                    onChange={(e) => {
                      field.onChange(e);
                      handleInputChange(e.target.value);
                    }}
                  />
                </div>
              )}
            />
          </div>
          <div className="my-3 flex justify-center ">
            <Button type="submit"> Create or update comment </Button>
          </div>
        </form>
      </div>
    </Dialog>
  );
}
