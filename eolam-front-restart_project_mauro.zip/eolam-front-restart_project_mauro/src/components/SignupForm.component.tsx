"use client";

import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {faUser, faLock} from "@fortawesome/free-solid-svg-icons";
import {useFormState, useFormStatus} from "react-dom";
import {useEffect, useState} from "react";

import {signup} from "@/utils/actionAuth.util";
import {textGray400} from "@/assets/styles/colors";

export default function SignupForm() {
  const {pending} = useFormStatus();
  const [state, action] = useFormState(signup, undefined);

  const [errorModalOpen, setErrorModalOpen] = useState(false);

  useEffect(() => {
    state?.error && setErrorModalOpen(true);
  }, [state]);

  return (
    <div>
      <form
        action={async (formData) => {
          action(formData);
        }}
        className="text-slate-950 space-y-4"
      >
        <div className="inner-shadow flex items-center bg-white p-2">
          <div className="w-6">
            <FontAwesomeIcon className={`${textGray400} mr-2`} icon={faUser} />
          </div>
          <input
            className="w-full rounded-sm bg-white text-black outline-none"
            id="user"
            name="user"
            placeholder="Insert your email"
            type="text"
          />
        </div>
        {state?.errors?.user ? <p>{state.errors.user}</p> : null}
        <div className="inner-shadow flex items-center bg-white p-2">
          <div className="w-6">
            <FontAwesomeIcon className={`${textGray400} mr-2`} icon={faLock} />
          </div>
          <input
            className="w-full rounded-sm bg-white text-black outline-none"
            id="password"
            name="password"
            placeholder="************"
            type="password"
          />
        </div>
        {state?.errors?.password ? (
          <div>
            <p>Password must:</p>
            <ul>
              {state.errors.password.map((error) => (
                <li key={error}>- {error}</li>
              ))}
            </ul>
          </div>
        ) : null}
        <div>
          <button
            aria-disabled={pending}
            className="w-full rounded-sm bg-pink-900 p-3 font-thin text-white"
            type="submit"
          >
            LOGIN
          </button>
        </div>
      </form>
      {errorModalOpen ? (
        <div className="blur-modal fixed left-0 top-0 flex h-full w-full items-center justify-center bg-gray-800 bg-opacity-50">
          <div className="flex flex-col items-center justify-center rounded bg-white p-4 text-black shadow-md">
            <p className="mb-5 mt-5 text-black">
              {state?.error
                ? "There is no User registered with that email or the password its wrong"
                : null}
            </p>
            <button
              className="rounded-sm bg-pink-900 pb-2 pl-3 pr-3 pt-2 text-white"
              type="button"
              onClick={() => setErrorModalOpen(false)}
            >
              Close
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}
