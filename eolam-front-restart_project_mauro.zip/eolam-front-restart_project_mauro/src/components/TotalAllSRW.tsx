import type {GetExercisesByReportAndStage} from "@/interfaces/exerciseUser";

import {totalSrwCalculate} from "@/utils/commonResourcesForms.util";

export default function TotalAllSRW({
  exMobility,
  exActivation,
  exStrength,
  inForm = false,
}: {
  exMobility: GetExercisesByReportAndStage[];
  exActivation: GetExercisesByReportAndStage[];
  exStrength: GetExercisesByReportAndStage[];
  inForm?: boolean;
}) {
  const {tSeries: seriesM, tRepetitions: repetM, tWeight: weightM} = totalSrwCalculate(exMobility);
  const {
    tSeries: seriesA,
    tRepetitions: repetA,
    tWeight: weightA,
  } = totalSrwCalculate(exActivation);
  const {
    tSeries: seriesS,
    tRepetitions: repetS,
    tWeight: weightS,
    pRpe,
  } = totalSrwCalculate(exStrength);

  const allSeries = seriesM + seriesA + seriesS;
  const allRepetitions = repetM + repetA + repetS;
  const allWeight = weightM + weightA + weightS;

  return (
    <div className="flex justify-center">
      {inForm ? (
        <>
          <div className="w-3/12" />
          <div className="w-1/12" />
          <div className="w-2/12">All series: {allSeries}</div>
          <div className="w-1/12" />
          <div className="w-2/12">All repetitions: {allRepetitions}</div>
          <div className="w-1/12" />
          <div className="w-2/12">All weight: {allWeight}</div>
          <div className="w-2/12" />
          <div className="w-1/12" />
        </>
      ) : (
        <>
          <div className="w-3/12" />
          <div className="w-2/12">All series: {allSeries}</div>
          <div className="w-2/12">All repetitions: {allRepetitions}</div>
          <div className="w-2/12">All weight: {allWeight}</div>
          <div className="w-2/12">Rpe average: {pRpe}</div>
          <div className="w-2/12" />
        </>
      )}
    </div>
  );
}
