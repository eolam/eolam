import type {GetExercisesByReportAndStage} from "@/interfaces/exerciseUser";

import {totalSrwCalculate} from "@/utils/commonResourcesForms.util";

export default function TotalSRWforStage({
  exercises,
  inForm = false,
}: {
  exercises: GetExercisesByReportAndStage[];
  inForm?: boolean;
}) {
  const {tSeries, tRepetitions, tWeight} = totalSrwCalculate(exercises);

  return (
    <div className="flex justify-center">
      <div className="w-3/12" />
      <div className="w-2/12">Series Total: {tSeries}</div>
      {inForm ? <div className="w-1/12" /> : null}
      <div className="w-2/12">Repetition Total: {tRepetitions}</div>
      {inForm ? <div className="w-1/12" /> : null}
      <div className="w-2/12">Weight Total: {tWeight === 0 ? "-" : tWeight}</div>
      {inForm ? <div className="w-1/12" /> : <div className="w-2/12" />}
      <div className="w-2/12" />
    </div>
  );
}
