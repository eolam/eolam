/* eslint-disable @typescript-eslint/no-unnecessary-condition */
import type {MouseEvent} from "react";
import type {Data} from "./ContextMenu/ContextMenu.interface";
import type {InExercise, InUser} from "@/app/api/_models/User.model";
import type {InVideo} from "@/app/api/_models/Video.model";
import type {FieldValues} from "react-hook-form";

import {useParams} from "next/navigation";
import {useEffect, useState} from "react";
import {useForm, Controller} from "react-hook-form";

import {bgTables, buttonColorSecondary, hoverColor, textWithe} from "@/assets/styles/colors";
import {deleteWeek, getUserTrainingHistoryById} from "@/utils/fetchWeek.utils";
import {deleteReport} from "@/utils/fetchReport.util";
import {repetitionType} from "@/utils/commonResourcesForms.util";

import {
  Button,
  Card,
  Collapse,
  Dialog,
  DialogHeader,
  DialogBody,
  DialogFooter,
  Checkbox,
} from "../mTailwind/tailwindMaterial";

import {ContextMenu} from "./ContextMenu/ContextMenu";
import {SelectField} from "./FormComponents/SelectField";
import {InputField} from "./FormComponents/InputField";

interface FormFields extends FieldValues {
  video: InVideo | null;
  stage: "MOVILITY" | "ACTIVATION" | "STRONG" | null;
  repetition_type: "TIME" | "AMOUNT" | null | boolean;
  series: number | null;
  check_side: boolean;
  repetition: number | null;
  left_weight: number | null;
  right_weight: number | null;
  single_weight: number | null;
  interval: number | null;
  comment: string;
}

type TrainingStage = "MOVILITY" | "ACTIVATION" | "STRONG";

const getStageTranslation = (stage: TrainingStage): string => {
  const translations: Record<TrainingStage, string> = {
    MOVILITY: "Movilidad",
    ACTIVATION: "Activación",
    STRONG: "Fuerza",
  };

  return translations[stage];
};

export default function TrainingHistoryCard() {
  const params = useParams();
  const id = params?.id as string;

  const [user, setUser] = useState<InUser | null>();

  const {weeks} = user ?? {week_number: 0, amount_training_per_week: 0, days: []};

  const stageConstant = ["MOVILITY", "ACTIVATION", "STRONG"];

  useEffect(() => {
    if (id) {
      loadUserTrainigHistory(id);
    }
  }, [id]);

  const loadUserTrainigHistory = async (id: string) => {
    try {
      const user = await getUserTrainingHistoryById(id);

      if ("error" in user) return;

      setUser(user);
    } catch (error) {
      console.log(error);
    }
  };

  const [openWeek, setOpenWeek] = useState<null | number>(null);
  const [openDay, setOpenDay] = useState<null | number>(null);

  const toggleOpen = (weekNumber: number) => {
    if (openWeek === weekNumber) {
      setOpenWeek(null);
    } else {
      setOpenWeek(weekNumber);
    }
  };

  const toggleOpenDay = (dayNumber: number) => {
    if (openDay === dayNumber) {
      setOpenDay(null);
    } else {
      setOpenDay(dayNumber);
    }
  };

  const createNewActivity = async (
    selectedWeekForNewActivity: {index_week: number; index_day: number},
    formData: FormFields,
  ) => {
    const {index_week, index_day} = selectedWeekForNewActivity;
    const {
      video,
      stage,
      repetition_type,
      series,
      check_side,
      repetition,
      left_weight,
      right_weight,
      single_weight,
      interval,
      comment,
    } = formData;

    const response = await fetch(`/api/user/training/${id}`, {
      method: "POST",
      body: JSON.stringify({
        index_week,
        index_day,
        video,
        stage,
        repetition_type,
        series,
        check_side,
        repetition,
        left_weight,
        right_weight,
        single_weight,
        interval,
        comment,
      }),
    });
  };
  const [selectedExercise, setSelectedExercise] = useState<any | null>(null);
  const handleModifyActivity = (exercise: InExercise) => {
    setSelectedExercise(exercise);

    // Pre-fill form with exercise values
    setValue("video", {
      value: exercise.name_exercise,
      label: exercise.name_exercise,
    });
    setValue("stage", {
      value: exercise.training_stage,
      label:
        exercise.training_stage == "MOVILITY"
          ? "Movilidad"
          : exercise.training_stage == "ACTIVATION"
            ? "Activación"
            : "Fuerza",
    });
    setValue("repetition_type", {
      value: exercise.repetition_type == "AMOUNT" ? "AMOUNT" : "TIME",
      label: exercise.repetition_type == "AMOUNT" ? "Cantidad" : "Tiempo",
    });
    setValue("series", exercise.series);
    setValue("check_side", exercise.check_side);
    setValue("repetition", exercise.repetition);
    setValue("left_weight", exercise.left_weight);
    setValue("right_weight", exercise.right_weight);
    setValue("single_weight", exercise.single_weight);
    setValue("interval", exercise.interval);
    setValue("comment", exercise.comment || "");

    // Update checkbox state
    setIsChecked(exercise.check_side);

    // Open modal
    setOpenModal(true);
  };

  const handleCloseModal = () => {
    setOpenModal(false);
    setSelectedExercise(null);
    reset();
  };

  const handleModalSubmit = async (formData: FormFields) => {
    if (selectedExercise) {
      const id_exercise = selectedExercise._id;

      await updateExercise(id_exercise, id, formData, selectedWeekForNewActivity);
    } else if (selectedWeekForNewActivity) {
      await createNewActivity(selectedWeekForNewActivity, formData);
    }

    handleCloseModal();
    loadUserTrainigHistory(id);
  };

  const updateExercise = async (
    id_exercise: string,
    id: string,
    formData: FormFields,
    selectedWeekForNewActivity: {index_week: number; index_day: number},
  ) => {
    const {index_week, index_day} = selectedWeekForNewActivity;
    const {
      video,
      stage,
      repetition_type,
      series,
      check_side,
      repetition,
      left_weight,
      right_weight,
      single_weight,
      interval,
      comment,
    } = formData;
    const payload = {
      id,
      id_exercise,
      index_week,
      index_day,
      video,
      stage,
      repetition_type,
      series,
      check_side,
      repetition,
      left_weight,
      right_weight,
      single_weight,
      interval,
      comment,
    };

    const response = await fetch(`/api/user/training/${id}`, {
      method: "PUT",
      body: JSON.stringify(payload),
    });
  };

  const createNewDay = async (index_week: number) => {
    const response = await fetch(`/api/user/training/${id}?index_week=${index_week}`, {
      method: "POST",
    });
    const userDb = (await response.json()) as InUser;

    setUser(userDb);
  };

  const initialContextMenu = {
    show: false,
    x: 0,
    y: 0,
  };
  const [contexMenuWeek, setContexMenuWeek] = useState(initialContextMenu);
  const [selectedWeek, setSelectedWeek] = useState<Data>({
    number: 0,
    id: 0,
  });

  const [contexMenuReport, setContexMenuReport] = useState(initialContextMenu);
  const [selectedReport, setSelectedReport] = useState<Data>({
    number: 0,
    id: 0,
  });

  function handleOnContextMenuWeek(
    e: MouseEvent<HTMLDivElement>,
    week_number: number,
    id_week: number,
  ) {
    e.preventDefault();
    const {pageX, pageY} = e;

    setContexMenuWeek({show: true, x: pageX, y: pageY});
    setSelectedWeek({number: week_number, id: id_week});
  }

  function handleOnContextMenuReport(
    e: MouseEvent<HTMLDivElement>,
    report_number: number,
    id_report: number,
  ) {
    e.preventDefault();
    const {pageX, pageY} = e;

    setContexMenuReport({show: true, x: pageX, y: pageY});
    setSelectedReport({number: report_number, id: id_report});
  }

  const onClickFunctionWeek = async (id_week: number) => {
    const response = await deleteWeek(id_week);

    if ("error" in response) {
      closeContextMenuWeek();
    } else {
      closeContextMenuWeek();
      loadUserTrainigHistory(id);
    }
  };

  const onClickFunctionReport = async (id_report: number) => {
    const response = await deleteReport(id_report);

    if ("error" in response) {
      closeContextMenuReport();
    } else {
      closeContextMenuReport();
      loadUserTrainigHistory(id);
    }
  };

  const closeContextMenuWeek = () => setContexMenuWeek(initialContextMenu);
  const closeContextMenuReport = () => setContexMenuReport(initialContextMenu);

  const [openModal, setOpenModal] = useState(false);
  const [selectedWeekForNewActivity, setSelectedWeekForNewActivity] = useState<{
    index_week: number;
    index_day: number;
  } | null>(null);

  const handleOpenNewActivityModal = (index_week: number, index_day: number) => {
    setSelectedWeekForNewActivity({index_week: index_week, index_day: index_day});
    setOpenModal(true);
  };

  const [videoSelect, setVideoSelect] = useState<InVideo[]>();
  const [isChecked, setIsChecked] = useState(true);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    loadExercisesSelect();
  }, []);

  const loadExercisesSelect = async () => {
    const response = await fetch("/api/video");
    const data = (await response.json()) as {message: InVideo[]};
    // await getAllVideos(1, search);

    if ("error" in response) return;
    if (data.message) {
      setVideoSelect(data.message);
    }
  };

  const {control, handleSubmit, setValue, watch, reset} = useForm<FormFields>({
    defaultValues: {
      id_exercise_type: null,
      repetition_type: null,
      series: null,
      check_side: true,
      repetition: null,
      left_weight: null,
      right_weight: null,
      single_weight: null,
      interval: null,
      comment: "",
    },
  });

  const handleCheckboxChange = (checked: boolean) => {
    setIsChecked(checked);
    if (checked) {
      setValue("single_weight", null);
    } else {
      setValue("left_weight", null);
      setValue("right_weight", null);
    }
  };

  const video = watch("video");
  const stage = watch("stage");
  const repetition_type = watch("repetition_type");
  const series = watch("series");
  const check_side = watch("check_side");
  const single_weight = watch("single_weight");
  const left_weight = watch("left_weight");
  const right_weight = watch("right_weight");
  const interval = watch("interval");
  const repetition = watch("repetition");
  const comment = watch("comment");
  const isButtonSaveDisabled =
    !video || !stage || !repetition_type || !repetition || !series || !interval;

  return (
    <div className={`${bgTables} m-2.5 h-min w-full rounded-lg text-white`}>
      <div className="rounded-t-lg bg-pink-700 pb-2 pt-2 text-center">Training history</div>
      <div>
        {contexMenuWeek.show ? (
          <ContextMenu
            closeContextMenu={closeContextMenuWeek}
            data={selectedWeek}
            text={`Delete InWeek number ${selectedWeek.number}`}
            x={contexMenuWeek.x}
            y={contexMenuWeek.y}
            onClickButton={onClickFunctionWeek}
          />
        ) : null}
      </div>

      <div>
        {contexMenuReport.show ? (
          <ContextMenu
            closeContextMenu={closeContextMenuReport}
            data={selectedReport}
            text={`Delete report number ${selectedReport.number}`}
            x={contexMenuReport.x}
            y={contexMenuReport.y}
            onClickButton={onClickFunctionReport}
          />
        ) : null}
      </div>

      <div className="w-full">
        {/* InWeek */}
        {weeks?.map(({week_number, days}, index_week) => {
          return (
            <div key={week_number}>
              <div onContextMenu={(e) => handleOnContextMenuWeek(e, week_number, week_number)}>
                <Button
                  fullWidth
                  className="rounded-none"
                  color="white"
                  size="sm"
                  variant="text"
                  onClick={() => toggleOpen(week_number)}
                >
                  {week_number} Week
                </Button>
              </div>
              <div className="divide-y divide-gray-600">
                <Collapse className="pl-2 pr-2" open={openWeek === week_number}>
                  <div className="text-xs">
                    {/* Ejercicios */}
                    {days.map((day, index_day) => (
                      <div key={day._id}>
                        <div
                          onContextMenu={(e) =>
                            handleOnContextMenuWeek(e, week_number, week_number)
                          }
                        >
                          <Button
                            fullWidth
                            className="rounded-none"
                            color="white"
                            size="sm"
                            variant="text"
                            onClick={() => toggleOpenDay(index_day)}
                          >
                            Dia {index_day + 1}
                          </Button>
                        </div>
                        <div className="divide-y divide-gray-100">
                          <Collapse className="pl-2 pr-2 " open={openDay === index_day}>
                            <Card className="w-full rounded-none bg-gray-800 text-white">
                              <div className="text-xs">
                                {/* Ejercicios */}
                                {day.exercises.map((exercise) => {
                                  const {report} = exercise;

                                  // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
                                  if (!report) return null;

                                  return (
                                    <div
                                      key={exercise._id}
                                      className="hover:cursor-pointer"
                                      onClick={() => {
                                        handleOpenNewActivityModal(index_week, index_day);
                                        handleModifyActivity(exercise);
                                      }}
                                      onContextMenu={(e) =>
                                        handleOnContextMenuReport(e, +exercise._id, +exercise._id)
                                      }
                                    >
                                      <div className="flex-col justify-between  p-2 pb-3 pt-3 hover:bg-gray-900">
                                        <p className="">
                                          Stage:{" "}
                                          {getStageTranslation(
                                            exercise.training_stage as TrainingStage,
                                          )}
                                        </p>
                                        <p className="">Exercise: {exercise.name_exercise}</p>
                                        <p className="">Series: {exercise.series}</p>
                                        <p className="">
                                          Tipo de repeticion por:{" "}
                                          {exercise.repetition_type == "AMOUNT"
                                            ? "Cantidad"
                                            : "Tiempo"}
                                        </p>
                                        <p>Repeticiones: {exercise.repetition}</p>
                                        {exercise.single_weight ? (
                                          <p className="">Peso simple: {exercise.single_weight}</p>
                                        ) : null}
                                        <p className="">Intervalo: {exercise.interval}</p>
                                        {exercise.left_weight ? (
                                          <p className="">
                                            Peso D-I: {exercise.left_weight} /{" "}
                                            {exercise.right_weight}
                                          </p>
                                        ) : null}

                                        <p className="">
                                          Rpe:{" "}
                                          {exercise.report.rpe ? ` ${exercise.report.rpe}` : " -"}
                                        </p>
                                        <p className="">
                                          Fecha:
                                          {exercise.report.day
                                            ? exercise.report.day.toLocaleDateString()
                                            : " No realizado"}
                                        </p>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </Card>
                            <button
                              className={`${buttonColorSecondary} ${textWithe}
                     mb-5 flex rounded p-1 text-center 
                     shadow hover:${hoverColor} w-full
                     justify-center rounded-sm text-sm`}
                              type="button"
                              onClick={() => handleOpenNewActivityModal(index_week, index_day)}
                            >
                              <div className=" font-normal">
                                + Nuevo ejercicio para el dia {index_day + 1}
                              </div>
                            </button>
                          </Collapse>
                        </div>
                      </div>
                    ))}
                  </div>
                  <button
                    className={`${buttonColorSecondary} ${textWithe}
                     mb-5 flex rounded p-1 text-center 
                     shadow hover:${hoverColor} w-full
                     justify-center rounded-sm text-sm`}
                    type="button"
                    onClick={() => createNewDay(week_number)}
                  >
                    <div className=" font-normal">+ Add a new day</div>
                  </button>
                </Collapse>
              </div>
            </div>
          );
        })}
      </div>
      <div className="mb-5" />
      <Dialog className="bg-gray-800 text-white" handler={handleCloseModal} open={openModal}>
        <DialogHeader>
          {selectedExercise ? "Modificar ejercicio" : "Nuevo ejercicio para el usuario"}
        </DialogHeader>
        <DialogBody>
          <form className="w-full" onSubmit={handleSubmit(handleModalSubmit)}>
            <div className="flex flex-col gap-4">
              {/* Stage */}
              <div className="w-full">
                <label className="text-sm" htmlFor="stage">
                  Stage
                </label>
                <SelectField
                  control={control}
                  defaultValue={selectedExercise?.training_stage}
                  id="stage"
                  isSearchable={false}
                  name="stage"
                  options={stageConstant?.map((stage) => ({
                    value: stage,
                    label: stage,
                  }))}
                />
              </div>
              {/* Exercise Select */}
              <div className="w-full">
                <label className="text-sm" htmlFor="video">
                  Ejercicio
                </label>
                {isMounted ? (
                  <SelectField
                    isSearchable
                    control={control}
                    id="exercise"
                    name="video"
                    options={videoSelect?.map((video) => ({
                      value: video,
                      label: video.name,
                    }))}
                  />
                ) : null}
              </div>

              {/* Series */}
              <div className="w-full">
                <label className="text-sm" htmlFor="series">
                  Series
                </label>
                <InputField
                  control={control}
                  id="series"
                  name="series"
                  placeholder="Number of series"
                  type="number"
                />
              </div>

              {/* Repetition Type */}
              <div className="w-full">
                <label className="text-sm" htmlFor="repetition_type">
                  Repetition Type
                </label>
                {isMounted ? (
                  <SelectField
                    isSearchable
                    control={control}
                    id="repetition_type"
                    name="repetition_type"
                    options={repetitionType}
                  />
                ) : null}
              </div>

              {/* Check Side */}
              <div className="flex items-center gap-2">
                <label className="text-sm" htmlFor="check_side">
                  Each Side
                </label>
                <Controller
                  control={control}
                  name="check_side"
                  render={({field}) => (
                    <Checkbox
                      ref={field.ref}
                      checked={field.value}
                      crossOrigin={undefined}
                      id="check_side"
                      name={field.name}
                      onChange={(e) => {
                        field.onChange(e.target.checked);
                        handleCheckboxChange(e.target.checked);
                      }}
                    />
                  )}
                />
              </div>

              {/* Repetitions */}
              <div className="w-full">
                <label className="text-sm" htmlFor="repetition">
                  Repetitions
                </label>
                <InputField
                  control={control}
                  disabled={false}
                  name="repetition"
                  placeholder="Number of repetitions"
                  type="number"
                  w=""
                />
              </div>

              {/* Weights */}
              <div className="grid grid-cols-2 gap-4">
                <div className="w-full">
                  <label className="text-sm" htmlFor="left_weight">
                    Left Weight
                  </label>
                  <Controller
                    control={control}
                    name="left_weight"
                    render={({field}) => (
                      <input
                        {...field}
                        className={`h-9 w-full rounded-md p-2 text-xs
                          ${!isChecked ? "bg-gray-500 text-gray-600" : "bg-white text-black"}`}
                        disabled={!isChecked}
                        placeholder="Weight left"
                        type="number"
                        value={field.value ?? ""}
                      />
                    )}
                  />
                </div>
                <div className="w-full">
                  <label className="text-sm" htmlFor="right_weight">
                    Right Weight
                  </label>
                  <Controller
                    control={control}
                    name="right_weight"
                    render={({field}) => (
                      <input
                        {...field}
                        className={`h-9 w-full rounded-md p-2 text-xs
                          ${!isChecked ? "bg-gray-500 text-gray-600" : "bg-white text-black"}`}
                        disabled={!isChecked}
                        placeholder="Weight right"
                        type="number"
                        value={field.value ?? ""}
                      />
                    )}
                  />
                </div>
              </div>

              {/* Single Weight */}
              <div className="w-full">
                <label className="text-sm" htmlFor="single_weight">
                  Weight
                </label>
                <Controller
                  control={control}
                  name="single_weight"
                  render={({field}) => (
                    <input
                      {...field}
                      className={`h-9 w-full rounded-md p-2 text-xs
                        ${isChecked ? "bg-gray-500 text-gray-600" : "bg-white text-black"}`}
                      disabled={isChecked}
                      placeholder="Weight"
                      type="number"
                      value={field.value ?? ""}
                    />
                  )}
                />
              </div>

              {/* Interval */}
              <div className="w-full">
                <label className="text-sm" htmlFor="interval">
                  Interval
                </label>
                <InputField
                  control={control}
                  disabled={false}
                  name="interval"
                  placeholder="Interval time"
                  type="number"
                  w=""
                />
              </div>
            </div>
          </form>
        </DialogBody>
        <DialogFooter>
          <Button className="mr-1" color="red" variant="text" onClick={handleCloseModal}>
            Cancel
          </Button>
          <Button
            color="green"
            disabled={isButtonSaveDisabled}
            variant="gradient"
            onClick={handleSubmit(handleModalSubmit)}
          >
            Create
          </Button>
        </DialogFooter>
      </Dialog>
    </div>
  );
}
