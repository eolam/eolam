// TABLA DE FORMULARIO. PREVISUALIZACION DE EJERCICIOS ANTES DE SER GUARDADOS

import type {GetExercisesByReportAndStage} from "@/interfaces/exerciseUser";

import {RiDeleteBin2Fill} from "react-icons/ri";
import {MdInsertComment} from "react-icons/md";

import {deleteExerciseUser} from "@/utils/fetchExerciseUser.util";
import {RepetitionType} from "@/utils/commonResourcesForms.util";

import {Tooltip, Button} from "../mTailwind/tailwindMaterial";

export default function ViewExercisesTable({
  exercise,
  loadTrainingExercises,
}: {
  exercise: GetExercisesByReportAndStage;
  loadTrainingExercises: () => Promise<void>;
}) {
  const {
    id,
    exerciseType,
    series,
    id_repetition_type,
    check_side,
    repetition,
    left_weight,
    right_weight,
    single_weight,
    interval,
    comment_admin,
  } = exercise;

  const repetitionType = id_repetition_type === RepetitionType.Amount ? "Amount" : "Time";
  const repetitionText = check_side
    ? `${repetition}${id_repetition_type === RepetitionType.Time ? '"' : ""}/${repetition}${id_repetition_type === RepetitionType.Time ? '"' : ""}`
    : `${repetition}${id_repetition_type === RepetitionType.Time ? '"' : ""}`;

  const handleDelete = async (id: number) => {
    await deleteExerciseUser(id);
    await loadTrainingExercises();
  };

  return (
    <div className="mt-3 flex justify-center">
      <div className="flex w-full items-center justify-evenly py-1 pl-1 pr-4 text-white hover:bg-blue-gray-800">
        <div className="flex w-48 pl-2">
          <div className="flex w-1/4 items-center">{comment_admin ? <MdInsertComment /> : ""}</div>
          <div className="flex w-3/4 items-start text-start">{exerciseType?.name}</div>
        </div>
        <div className="w-24">{series}</div>
        <div className="w-24">{repetitionType}</div>
        <div className="w-24">{check_side ? "Yes" : "No"}</div>
        <div className="w-24">{repetitionText}</div>
        <div className="w-24">{left_weight === 0 ? "-" : left_weight}</div>
        <div className="w-24">{right_weight === 0 ? "-" : right_weight}</div>
        <div className="w-24">{single_weight === 0 ? "-" : single_weight}</div>
        <div className="w-24">{interval ?? "-"}</div>
        <div className="w-14">
          <div className="flex w-20 justify-center">
            <Tooltip
              animate={{
                mount: {scale: 1, y: 0},
                unmount: {scale: 0, y: 25},
              }}
              className="text-xs"
              content="Delete exercise"
            >
              <Button onClick={() => handleDelete(id)}>
                <RiDeleteBin2Fill className="h-5 w-5 fill-white " />
              </Button>
            </Tooltip>
          </div>
        </div>
      </div>
    </div>
  );
}
