// TABLA DE ENTRENAMIENTO YA REALIZADO

import type {GetExercisesByReportAndStage} from "@/interfaces/exerciseUser";

import {bgAppDark} from "@/assets/styles/colors";
import {RepetitionType} from "@/utils/commonResourcesForms.util";

export default function ViewTableTraining({
  exercise,
  index,
}: {
  exercise: GetExercisesByReportAndStage;
  index: number;
}) {
  const {
    exerciseType,
    series,
    id_repetition_type,
    check_side,
    repetition,
    left_weight,
    right_weight,
    single_weight,
    rpe_scale,
    interval,
  } = exercise;

  const repetitionText = check_side
    ? `${repetition}${id_repetition_type === RepetitionType.Time ? '"' : ""}/${repetition}${id_repetition_type === RepetitionType.Time ? '"' : ""}`
    : `${repetition}${id_repetition_type === RepetitionType.Time ? '"' : ""}`;
  const weight = check_side
    ? `${left_weight ? left_weight : "-"}/${right_weight ? right_weight : "-"}`
    : single_weight
      ? single_weight
      : "-";

  const alterColor = "bg-blue-gray-900";

  return (
    <div className={`flex justify-center ${bgAppDark}  mx-3 `}>
      {/* Exercise  */}
      <div className={`flex w-3/12 justify-center p-2 ${index % 2 === 0 ? alterColor : ""}`}>
        <div className={`flex w-60 items-center justify-center text-center `}>
          {exerciseType?.name}
        </div>
      </div>

      {/* Series  */}
      <div className={`flex w-2/12 justify-center  ${index % 2 === 0 ? alterColor : ""}  `}>
        <div className={`flex w-20 items-center justify-center `}>{series}</div>
      </div>

      {/* Repetitions number  */}
      {/* Modificar de acuerdo a tipo de repe y check  */}
      <div className={`flex w-2/12 justify-center ${index % 2 === 0 ? alterColor : ""}`}>
        <div className="flex w-20 items-center justify-center">{repetitionText}</div>
      </div>

      {/* Weight */}
      <div className={`flex w-2/12 justify-center ${index % 2 === 0 ? alterColor : ""}`}>
        <div className="flex w-20 items-center justify-center">{weight}</div>
      </div>

      {/* Rpe  */}
      <div className={`flex w-2/12 justify-center ${index % 2 === 0 ? alterColor : ""}`}>
        <div className="flex w-20 items-center justify-center">
          {rpe_scale ? `${rpe_scale.scale} ${rpe_scale.name}` : "-"}
        </div>
      </div>

      {/* Interval  */}
      <div className={`flex w-2/12 justify-center ${index % 2 === 0 ? alterColor : ""}`}>
        <div className="flex w-20 items-center justify-center">{interval ? interval : "-"}</div>
      </div>
    </div>
  );
}
