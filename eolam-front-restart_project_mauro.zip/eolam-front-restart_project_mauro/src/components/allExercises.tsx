import type {InVideo} from "@/interfaces/exerciseType.interface";

import {MdOutlineDelete} from "react-icons/md";
import {useState} from "react";

import {deleteExcerciseById} from "@/utils/fetchExercise.util";

import {
  Button,
  Card,
  CardBody,
  Typography,
  Dialog,
  DialogBody,
  DialogFooter,
} from "../mTailwind/tailwindMaterial";

interface Props {
  videos: InVideo[];
  loadExercises: (page: number) => Promise<void>;
  page: number;
}

export default function AllExercises({videos, loadExercises, page}: Props) {
  const [videoLink, setVideoLink] = useState("");
  const [idToDelete, setIdToDelete] = useState(0);
  const [size, setSize] = useState<string | null>(null);

  const handleDelete = async (id: number) => {
    setSize("xs");
    setIdToDelete(id);
  };

  const closeDialogAfirmative = async () => {
    await deleteExcerciseById(idToDelete);
    if (videos.length === 1) loadExercises(1);
    if (videos.length !== 1) loadExercises(page);
    setSize(null);
  };

  const closeDialogCancel = async () => {
    setSize(null);
  };

  const openVideo = (link: string) => {
    setSize("sm");
    setVideoLink(link);
  };

  return (
    <div className="m-4  ml-6 mr-6 ">
      <div className="flex flex-wrap  justify-between">
        {videos.map((video) => {
          return (
            <div key={video.id} className="flex justify-between">
              <Card className="min-auto m-2 flex h-12 w-52 justify-center">
                <CardBody className="ml-2 flex items-center justify-between p-2">
                  <div>
                    <Typography
                      className="cursor-pointer text-center text-xs font-semibold capitalize"
                      onClick={() => openVideo(video.url)}
                    >
                      {video.name}
                    </Typography>
                  </div>
                  <div className="ml-3">
                    <MdOutlineDelete
                      className="cursor-pointer"
                      onClick={() => handleDelete(video.id)}
                    />
                  </div>
                </CardBody>
              </Card>
            </div>
          );
        })}
        <Dialog className=" " handler={setSize} open={size === "xs"} size="xs">
          <DialogBody className="texs-xs">
            Are you sure you want to delete this exercise?
          </DialogBody>
          <DialogFooter>
            <Button variant="gradient" onClick={closeDialogAfirmative}>
              <span>Acept</span>
            </Button>
            <Button className="ml-4" color="red" variant="gradient" onClick={closeDialogCancel}>
              <span>Cancel</span>
            </Button>
          </DialogFooter>
        </Dialog>

        <Dialog
          className="flex justify-center bg-transparent shadow-none"
          handler={setSize}
          open={size === "sm"}
        >
          <iframe
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
            height="491"
            src={videoLink}
            title={videoLink}
            width="280"
          />
        </Dialog>
      </div>
    </div>
  );
}
