"use client";
import type {IconProp} from "@fortawesome/fontawesome-svg-core";

import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {useRouter} from "next/navigation";

export default function Button({
  text,
  icon,
  widthIcon,
  color,
  textColor,
  hoverColor,
  route = "/",
}: {
  text: string;
  icon?: IconProp;
  widthIcon?: string;
  color: string;
  textColor: string;
  hoverColor: string;
  route?: string;
}) {
  const router = useRouter();

  return (
    <button
      className={`${color} ${textColor} mt-10 flex w-11/12 rounded p-4 text-center shadow hover:${hoverColor} rounded-sm`}
      type="button"
      onClick={async () => {
        router.push(route);
      }}
    >
      <div className={widthIcon}>{icon ? <FontAwesomeIcon icon={icon} /> : null}</div>
      <div className="ml-4">
        <p>{text}</p>
      </div>
    </button>
  );
}
