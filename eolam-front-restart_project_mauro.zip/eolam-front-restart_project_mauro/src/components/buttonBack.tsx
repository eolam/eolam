"use client";
import {faArrowLeft} from "@fortawesome/free-solid-svg-icons";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {usePathname, useRouter} from "next/navigation";

export default function ButtonBack() {
  const pathName = usePathname();

  const router = useRouter();

  const handleBack = () => {
    router.back();
  };

  return (
    <>
      {!(pathName === "/admin-dashboard") && (
        <button type="button" onClick={handleBack}>
          <div className="w-4">
            <FontAwesomeIcon className="fas fa-arrow-left" icon={faArrowLeft} />
          </div>
          <div className="mt-1 text-xs">
            <p>Back</p>
          </div>
        </button>
      )}
    </>
  );
}
