"use client";
import {faRightFromBracket} from "@fortawesome/free-solid-svg-icons";
import {FontAwesomeIcon} from "@fortawesome/react-fontawesome";
import {signOut, useSession} from "next-auth/react";
import React from "react";

import {logout} from "@/utils/actionAuth.util";

export default function ButtonLogout() {
  const {data: session} = useSession();

  async function deleteSession() {
    session && (await signOut());
    logout();
  }

  return (
    <button
      className="flex flex-col items-center"
      type="button"
      onClick={async () => {
        await deleteSession();
      }}
    >
      <div className="w-5">
        <FontAwesomeIcon icon={faRightFromBracket} />
      </div>
      <div className="mt-1 text-xs">
        <p>Logout</p>
      </div>
    </button>
  );
}
