"use client";
import type {KeyboardEvent} from "react";

import {useState} from "react";

export default function MessageDay() {
  const [messageOfTheDayState, setMessageOfTheDayState] = useState("");

  const handleKeyPress = (event: KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter") {
      setMessageOfTheDayState((event.currentTarget as HTMLInputElement).value);
    }
  };

  return (
    <div>
      <div className="mb-4 bg-white  shadow">
        <input
          className="inner-shadow w-full rounded bg-white p-2 text-black"
          placeholder="Message of the day"
          onKeyPress={handleKeyPress}
        />
      </div>
      <div className="mt-10 text-center text-7xl font-bold">
        <p>{messageOfTheDayState}</p>
      </div>
    </div>
  );
}
