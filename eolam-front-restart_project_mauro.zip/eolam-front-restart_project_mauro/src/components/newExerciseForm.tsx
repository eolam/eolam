"use client";

import type {SetStateAction} from "react";

import {useState} from "react";

import {createNewActivity} from "@/utils/fetchExercise.util";

import {Input, Button, Dialog, DialogBody, DialogFooter} from "../mTailwind/tailwindMaterial";

export default function NewExerciseForm({
  loadExercises,
  page,
}: {
  loadExercises: (page: number) => Promise<void>;
  page: number;
}) {
  const [htmlExercise, setHtmlExercise] = useState("");
  const [nameExercise, setNameExercise] = useState<string>("");
  const [urlExercise, setUrlExercise] = useState<string | null>("");

  const [size, setSize] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>("");
  const [successMsg, setSuccessMsg] = useState<string | null>("");

  const handleInputHtml = (e: {target: {value: SetStateAction<string>}}) => {
    setHtmlExercise(e.target.value);
  };

  const handleNameExercise = async (e: {preventDefault: () => void}) => {
    e.preventDefault();
    const tempElement = document.createElement("div");

    tempElement.innerHTML = htmlExercise;
    const iframe = tempElement.querySelector("iframe");

    if (!iframe) {
      setNameExercise("");
      setUrlExercise(null);

      return;
    }

    iframe.getAttribute("src") ? setUrlExercise(iframe.getAttribute("src")) : setUrlExercise(null);
    const title = iframe.getAttribute("title");

    title && setNameExercise(title);
  };

  const handleInputEditName = async (e: {target: {value: SetStateAction<string>}}) => {
    setNameExercise(e.target.value);
  };

  const handleCreateExercise = async () => {
    if (!urlExercise) return;
    const results = await createNewActivity({name: nameExercise, src: urlExercise});

    if ("error" in results) {
      setSize("xs");
      setErrorMsg(results.message);
    } else {
      setSize("xs");
      setSuccessMsg(`New Exercise "${nameExercise}" registered successfully.`);
      setHtmlExercise("");
      setNameExercise("");
      setUrlExercise(null);
    }
  };

  const closeDialog = () => {
    if (errorMsg) {
      setSize(null);
      setErrorMsg("");
      setSuccessMsg("");
    } else {
      loadExercises(page);
      setErrorMsg("");
      setSuccessMsg("");
      setSize(null);
    }
  };

  return (
    <div className="flex">
      <div className="m-4 justify-start">
        <div className="ml-4  w-52">
          <Input
            className="text-xs "
            color="white"
            crossOrigin={undefined}
            label="Insert here html exercise.."
            value={htmlExercise}
            onChange={handleInputHtml}
          />
        </div>

        <div className="ml-4 mt-2">
          <Button
            className="w-52 bg-pink-800 font-light capitalize "
            variant="filled"
            onClick={handleNameExercise}
          >
            Previsualize new exercise
          </Button>
        </div>
      </div>

      <div className="flex-col justify-start">
        <div className="mt-4 w-64">
          <Input
            className="text-xs uppercase"
            color="white"
            crossOrigin={undefined}
            label="Name exercise.."
            value={nameExercise}
            onChange={handleInputEditName}
          />
        </div>
        <div className="mt-2">
          <Button
            className="w-64 bg-pink-600 font-light capitalize"
            disabled={!urlExercise}
            variant="filled"
            onClick={handleCreateExercise}
          >
            +Create new exercise
          </Button>

          <Dialog handler={setSize} open={size === "xs"} size="xs">
            <DialogBody className="texs-xs">
              {errorMsg}
              {successMsg}
            </DialogBody>
            <DialogFooter>
              <Button variant="gradient" onClick={closeDialog}>
                <span>Ok</span>
              </Button>
            </DialogFooter>
          </Dialog>
        </div>
      </div>
    </div>
  );
}
