/* eslint-disable react/hook-use-state */
/* eslint-disable @typescript-eslint/no-unnecessary-condition */
"use client";
import type {MouseEvent} from "react";
import type {Data} from "./ContextMenu/ContextMenu.interface";
import type {ExerciseType} from "@/interfaces/exerciseType.interface";
import type {GetExercisesByReportAndStage} from "@/interfaces/exerciseUser";
import type {FormDataSubmit} from "@/utils/commonResourcesForms.util";

import {useEffect, useState} from "react";
import {useForm, Controller} from "react-hook-form";
import {PiFilePlus} from "react-icons/pi";

import {bgAppDark} from "@/assets/styles/colors";
import {getAllVideos} from "@/utils/fetchExercise.util";
import {getExerciseByReportAndStage} from "@/utils/fetchExerciseUser.util";
import {
  FORM_HEAD,
  onSubmitForm,
  repetitionType,
  TrainingStage,
} from "@/utils/commonResourcesForms.util";
import {getNewReport} from "@/utils/localStorage/newReport";

import {Typography, Tooltip, Button, Checkbox} from "../mTailwind/tailwindMaterial";

import ViewExercisesTable from "./ViewCreatedExercisesTable";
import {SelectField} from "./FormComponents/SelectField";
import {InputField} from "./FormComponents/InputField";
import TotalSRWforStage from "./TotalSRWforStage";
import {ContextMenu} from "./ContextMenu/ContextMenu";
import NewComment from "./NewComment";

export default function NewMobilityTable() {
  const {control, handleSubmit, setValue, watch, reset} = useForm({
    defaultValues: {
      id_exercise_type: null,
      id_repetition_type: null,
      series: null,
      check_side: true,
      repetition: null,
      left_weight: null,
      right_weight: null,
      single_weight: null,
      interval: null,
    },
  });

  const [repType] = useState(repetitionType);

  const [exercisesSelect, setExercisesSelect] = useState<ExerciseType[]>();

  const [search] = useState("");

  const [mobilityExercises, setMobility] = useState<GetExercisesByReportAndStage[]>();

  const [isChecked, setIsChecked] = useState(true);

  const id = Date.now().toString();

  const [isMounted, setIsMounted] = useState(false);

  const loadExercisesSelect = async (search?: string) => {
    const response = await getAllVideos(1, search);

    if ("error" in response) return;
    setExercisesSelect(response.results);
  };

  const loadMobilityExercises = async () => {
    const report = getNewReport();

    if (!report) return;
    const id_report = report.id;
    const response = await getExerciseByReportAndStage(id_report, TrainingStage.Mobility);

    if ("error" in response) return;
    setMobility(response.results);
  };

  useEffect(() => setIsMounted(true), []);

  useEffect(() => {
    loadExercisesSelect(search);
  }, [search]);

  useEffect(() => {
    loadMobilityExercises();
  }, []);

  const handleCheckboxChange = (checked: boolean) => {
    setIsChecked(checked);
    if (checked) {
      setValue("single_weight", null);
    } else {
      setValue("left_weight", null);
      setValue("right_weight", null);
    }
  };

  const onSubmitMobility = async (data: FormDataSubmit) => {
    const results = await onSubmitForm(data, TrainingStage.Mobility);

    if (!results || "error" in results) return;
    setMobility(results);
    reset();
  };

  const exercise = watch("id_exercise_type");
  const repeType = watch("id_repetition_type");
  const repetition = watch("repetition");
  const series = watch("series");
  // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
  const isButtonSaveDisabled = !exercise || !repeType || !repetition || !series;

  // MENU CONTEXT
  const initialContextMenu = {
    show: false,
    x: 0,
    y: 0,
  };
  const closeContextMenuComment = () => setContexMenuComment(initialContextMenu);
  const [contexMenuComment, setContexMenuComment] = useState(initialContextMenu);
  const [selectedExercise, setSelectedExercise] = useState<Data>({
    id: 0,
    name: "",
  });

  const onClickFunctionComment = async () => {
    handlerSize();
    closeContextMenuComment();
  };

  function handleOnContextMenuComment(
    e: MouseEvent<HTMLDivElement>,
    id: number,
    name = "",
    comment = "",
  ) {
    e.preventDefault();
    const {pageX, pageY} = e;

    setContexMenuComment({show: true, x: pageX, y: pageY});
    setSelectedExercise({id, name});
    setDefaultComment(comment);
  }

  const [size, setSize] = useState<string>("");
  const [defaultComment, setDefaultComment] = useState("");

  const handlerSize = () => {
    const value = size === "xs" ? "" : "xs";

    setSize(value);
  };

  return (
    <div className="flex flex-col justify-center  pb-8 ">
      <div>
        {contexMenuComment.show ? (
          <ContextMenu
            closeContextMenu={closeContextMenuComment}
            data={selectedExercise}
            text={`Add or modify a comment to exercise ${selectedExercise.name}`}
            x={contexMenuComment.x - 5}
            y={contexMenuComment.y - 100}
            onClickButton={onClickFunctionComment}
          />
        ) : null}
      </div>
      <NewComment
        exercise_name={selectedExercise.name ? selectedExercise.name : ""}
        id_exercise={selectedExercise.id}
        initialComment={defaultComment}
        loadTrainingExercises={loadMobilityExercises}
        setSize={handlerSize}
        size={size}
      />
      <form className="w-full pl-4 pr-4" onSubmit={handleSubmit(onSubmitMobility)}>
        <div className={`flex flex-col text-center ${bgAppDark} `}>
          <div className="mt-4 flex justify-evenly">
            {FORM_HEAD.map((head) => (
              <div
                key={head}
                className={`content-center border-b ${head == "Exercise" ? "w-48 pl-2" : "w-24"}`}
              >
                <Typography
                  className="mb-4 font-bold opacity-70 "
                  color="white"
                  variant="paragraph"
                >
                  {head}
                </Typography>
              </div>
            ))}

            <div className="w-16 border-b p-2 text-white " />
          </div>
          {/*Previsualizacion de Ejercicios*/}
          {mobilityExercises?.map((exercise) => {
            return (
              <div
                key={exercise.id}
                onContextMenu={(e) =>
                  handleOnContextMenuComment(
                    e,
                    exercise.id,
                    exercise.exerciseType?.name,
                    exercise.comment_admin,
                  )
                }
              >
                <ViewExercisesTable
                  exercise={exercise}
                  loadTrainingExercises={loadMobilityExercises}
                />
              </div>
            );
          })}

          {/* Formulario  */}
          <div className={`flex justify-evenly ${bgAppDark} my-3`}>
            {/* Search with select  */}
            <div className={` w-48`}>
              {isMounted ? (
                <SelectField
                  control={control}
                  id={id}
                  name="id_exercise_type"
                  options={exercisesSelect}
                />
              ) : null}
            </div>

            {/* Series  */}
            <div className="flex w-24 justify-center">
              <div className="flex w-20 justify-center">
                <InputField
                  control={control}
                  name="series"
                  placeholder="Number of series"
                  type="number"
                />
              </div>
            </div>

            {/* Repetition type  */}
            <div className="flex w-28 justify-center">
              {isMounted ? (
                <SelectField
                  control={control}
                  id={id}
                  name="id_repetition_type"
                  options={repType}
                />
              ) : null}
            </div>

            {/* One or each side check */}
            <div className="flex w-24 justify-center">
              <div className="flex w-20 justify-center">
                <Controller
                  control={control}
                  name="check_side"
                  render={({field}) => (
                    <Checkbox
                      ref={field.ref}
                      checked={field.value}
                      crossOrigin={undefined}
                      name={field.name}
                      onChange={(e) => {
                        field.onChange(e.target.checked);
                        handleCheckboxChange(e.target.checked);
                      }}
                    />
                  )}
                />
              </div>
            </div>

            {/* Repetitions number  */}
            <div className="flex w-24 justify-center">
              <div className="flex w-20 justify-center">
                <InputField
                  control={control}
                  name="repetition"
                  placeholder="Number of repetitions"
                  type="number"
                />
              </div>
            </div>

            {/* Weight Left */}
            <div className="flex w-24 justify-center">
              <div className="flex w-20 justify-center">
                <Controller
                  control={control}
                  name="left_weight"
                  render={({field}) => (
                    <input
                      {...field}
                      className={`h-9 w-16 rounded-md p-2 text-xs
                            ${!isChecked ? "bg-gray-500 text-gray-600" : "bg-white text-black"}`}
                      disabled={isChecked ? false : true}
                      id="series"
                      placeholder="Weight left"
                      type="number"
                      value={field.value ?? ""}
                    />
                  )}
                />
              </div>
            </div>

            {/* Weight Right  */}
            <div className="flex w-24 justify-center">
              <div className="flex w-20 justify-center">
                <Controller
                  control={control}
                  name="right_weight"
                  render={({field}) => (
                    <input
                      {...field}
                      className={`h-9 w-16 rounded-md p-2 text-xs
                          ${!isChecked ? "bg-gray-500 text-gray-600" : "bg-white text-black"}`}
                      disabled={isChecked ? false : true}
                      id="series"
                      placeholder="Weight right"
                      type="number"
                      value={field.value ?? ""}
                    />
                  )}
                />
              </div>
            </div>
            {/* Weight */}
            <div className="flex w-24 justify-center">
              <div className="flex w-20 justify-center">
                <Controller
                  control={control}
                  name="single_weight"
                  render={({field}) => (
                    <input
                      disabled={isChecked ? true : false}
                      {...field}
                      className={`h-9 w-16 rounded-md p-2 text-xs
                          ${isChecked ? "bg-gray-500 text-gray-600" : "bg-white text-black"}`}
                      id="series"
                      placeholder="Weight"
                      type="number"
                      value={field.value ?? ""}
                    />
                  )}
                />
              </div>
            </div>

            {/* Interval  */}
            <div className="flex w-24 justify-center">
              <div className="flex w-20 justify-center">
                <InputField
                  control={control}
                  name="interval"
                  placeholder="Interval time"
                  type="number"
                />
              </div>
            </div>

            {/* Save button  */}
            <div className="flex w-16 justify-center">
              <div className="flex w-20 justify-center">
                <Tooltip
                  animate={{
                    mount: {scale: 1, y: 0},
                    unmount: {scale: 0, y: 25},
                  }}
                  className="text-xs"
                  content="Save new mobility"
                >
                  <Button disabled={isButtonSaveDisabled} type="submit">
                    <PiFilePlus className="h-5 w-5 fill-white " />
                  </Button>
                </Tooltip>
              </div>
            </div>
          </div>
        </div>
      </form>

      {/* Previsualizacion de totales  */}
      <div className="mx-4 bg-blue-gray-800 py-2 font-light text-white">
        {mobilityExercises ? <TotalSRWforStage inForm exercises={mobilityExercises} /> : null}
      </div>
    </div>
  );
}
