"use client";

export default function UserStateButton({
  text,
  textColor,
  unselectColor,
  selectColor,
  isActive,
  onButtonClicked,
}: {
  text: string;
  textColor: string;
  unselectColor: string;
  selectColor: string;
  isActive: boolean;
  onButtonClicked: () => void;
}) {
  return (
    <div>
      <button
        className={`rounded-full px-4 py-2 ${textColor} ${isActive ? selectColor : unselectColor}`}
        type="button"
        onClick={onButtonClicked}
      >
        {text}
      </button>
    </div>
  );
}
