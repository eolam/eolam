export interface ResponseError {
  message: string;
  error: boolean;
  code: number;
  results: null;
  data: null;
}
