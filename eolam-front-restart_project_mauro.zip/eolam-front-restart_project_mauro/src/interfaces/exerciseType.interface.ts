export interface ExerciseType {
  id: number;
  name: string;
  // Add other relevant fields
}

export interface FormFieldsMethods {
  id_exercise_type: number | null;
  id_repetition_type: number | null;
  series: number | null;
  check_side: boolean;
  repetition: number | null;
  left_weight: number | null;
  right_weight: number | null;
  single_weight: number | null;
  interval: number | null;
}
