import type {RepetitionType} from "@/utils/commonResourcesForms.util";

export interface PostExerciseToUser {
  id_report: number;
  id_training_stage: number;
  id_exercise_type: number;
  id_repetition_type: RepetitionType;
  check_side: boolean;
  series: number;
  repetition: number;
  left_weight?: number;
  right_weight?: number;
  single_weight?: number;
  interval?: number;
  comment_admin?: string;
  comment_user?: string;
}

export interface UpdateExerciseType {
  comment_admin?: string;
  comment_user?: string;
}

export interface GetExercisesByReportAndStage extends PostExerciseToUser {
  id: number;
  id_rpe?: number;
  exerciseType?: {
    id: number;
    name: string;
  };
  rpe_scale?: {
    id: number;
    name: string;
    scale: number;
  };
}
