import type {FieldValues} from "react-hook-form";

export interface PaymentMethod {
  id: number;
  description: string;
  data: string;
  id_user: number;
}

export interface PaymentMethodPUT {
  data: string;
}

export interface PaymentMethodForm {
  data: string;
  id: number;
}

export interface MethodIdSelect {
  value: number;
  label: string;
}

export interface FormFieldsMethods extends FieldValues {
  methodId: MethodIdSelect;
  newData: string;
}
