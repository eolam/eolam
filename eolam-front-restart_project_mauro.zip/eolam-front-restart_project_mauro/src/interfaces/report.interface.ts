export interface NewReport {
  status: boolean;
  id: number;
  id_week: number;
  report_number: number;
}
