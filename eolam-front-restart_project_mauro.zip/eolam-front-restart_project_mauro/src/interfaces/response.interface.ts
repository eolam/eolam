import type {ResponseError} from "./error.interface";

export interface ResponseOk<T> {
  message: string;
  totalItems: number;
  totalPages: number;
  results: T[];
  data: T[];
}

export type Response<T> = ResponseOk<T> | ResponseError;

export function isResponseOk<T>(response: Response<T>): response is ResponseOk<T> {
  return response.data ? true : false;
}
