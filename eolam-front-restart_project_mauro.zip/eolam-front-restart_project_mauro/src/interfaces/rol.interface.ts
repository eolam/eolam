export enum UserRol {
  Admin = 1,
  User,
}
