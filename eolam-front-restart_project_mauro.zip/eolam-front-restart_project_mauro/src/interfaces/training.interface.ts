import type {InVideo} from "@/app/api/_models/Video.model";

export interface NewTrainingBody {
  id_exercise: string;
  id: string;
  index_week: number;
  index_day: number;
  video: InVideo;
  exercise_type: string;
  stage: {value: "MOVILITY" | "ACTIVATION" | "STRONG"};
  repetition_type: "TIME" | "AMOUNT" | boolean;
  series: number;
  check_side: boolean;
  repetition: number;
  left_weight: number | null;
  right_weight: number | null;
  single_weight: number | null;
  interval: number;
  comment?: string;
}
