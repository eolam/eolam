import type {BuiltInProviderType} from "next-auth/providers/index";
import type {ClientSafeProvider, LiteralUnion} from "next-auth/react";

export type Providers = Record<LiteralUnion<BuiltInProviderType>, ClientSafeProvider>;
