import type {ExerciseType} from "./exerciseType.interface";
import type {InDay} from "@/app/api/_models/User.model";

export interface User {
  id: string;
  is_admin: boolean;
  email: string;
  password: string;
  first_name: string;
  last_name: string;
  birthday: string;
  number_trainning_week: number;
  gym_name: string;
  day_of_payment: string;
  goals: string;
  last_training_day: string;
  weeks: InWeek[];
}

export interface ListUserReduced {
  _id: string;
  is_admin: boolean;
  email: string;
  password: string;
  first_name: string;
  last_name: string;
  birthday: string;
  number_trainning_week: number;
  gym_name: string;
  day_of_payment: string;
  goals: string;
  last_training_day: string;
  weeks: InWeek[];
}

// export interface Week {
//   id: number;
//   id_user: number;
//   id_week: number;
//   week_number: number;
//   reports: Report[];
// }

export type TrainingHistory = InWeek[];

export interface InWeek extends Document {
  week_number: number;
  amount_training_per_week: number;
  days: InDay[];
}

export interface Report {
  id: number;
  id_week: number;
  id_rpe: number;
  report_number: number;
  date: string;
  status: boolean;
  exerciseUsers: ExerciseUser[];
}

export interface ExerciseUser {
  id: number;
  id_report: number;
  id_exercise_type: number;
  id_rpe: number;
  id_training_stage: number;
  check_side: boolean;
  id_repetition_type: number;
  series: number;
  repetition: number;
  left_weight: number;
  right_weight: number;
  single_weight: number;
  interval: number;
  exerciseType: ExerciseType;
}

export interface UserEmail {
  userEmail: string;
}
