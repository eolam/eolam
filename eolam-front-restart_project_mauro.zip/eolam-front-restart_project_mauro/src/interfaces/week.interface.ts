import type {FieldValues} from "react-hook-form";

export interface NewWeek {
  id: number;
  id_user: number;
  week_number: number;
}

export interface FormFieldsWeek extends FieldValues {
  week_number: number;
  id: number;
}
