import type { NextRequest } from "next/server";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { getToken } from "next-auth/jwt";
import { cookie } from "./app/lib/session";
// import type {NextRequest} from "next/server";

// import {cookies} from "next/headers";
// import {NextResponse} from "next/server";

// import {cookie} from "./app/lib/session";

const publicRoutes = ["/"];

export default async function middleware(req: NextRequest) {
    const path = req.nextUrl.pathname;
    const isProtectedRoute = path.startsWith("/admin-dashboard");
    const isPublicRoute = publicRoutes.includes(path);
    
    // Verificar sesión local
    const localAuth = cookies().get(cookie.name)?.value;
    
    // Verificar sesión de NextAuth
    const session = await getToken({ 
        req,
        secret: process.env.NEXTAUTH_SECRET 
    });

    const isAuthenticated = session || localAuth;

    if (!isAuthenticated && isProtectedRoute) {
        return NextResponse.redirect(new URL("/", req.nextUrl));
    }

    if (isPublicRoute && isAuthenticated && !isProtectedRoute) {
        return NextResponse.redirect(new URL("/admin-dashboard", req.nextUrl));
    }

    return NextResponse.next();
}

// export default async function middleware(req: NextRequest) {
//     const path = req.nextUrl.pathname;
//     const isProtectedRoute = req.nextUrl.pathname.startsWith("/admin-dashboard");
//     const isPublicRoute = publicRoutes.includes(path);
//     const currentCookie = cookies().get(cookie.name)?.value;
//     const authGoogle = cookies().get("next-auth.session-token")?.value.trim();
//     if (!authGoogle && !currentCookie && isProtectedRoute) {
//       return NextResponse.redirect(new URL("/", req.nextUrl));
//     }
//     if (
//       isPublicRoute &&
//       (currentCookie || authGoogle) &&
//       !req.nextUrl.pathname.startsWith("/admin-dashboard")
//     ) {
//       return NextResponse.redirect(new URL("/admin-dashboard", req.nextUrl));
//     }
//     return NextResponse.next();
//   }
//   export const config = {
//     matcher: ["/((?!api|_next/static|_next/image|.*\\.png$).*)"],
// }
