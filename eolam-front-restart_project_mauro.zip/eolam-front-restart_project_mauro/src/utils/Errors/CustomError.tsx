export class CustomError extends Error {
  public readonly code: number;
  public readonly error: boolean;

  constructor(message: string, code: number, error: boolean) {
    super(message), (this.code = code);
    this.error = error;
  }
}
