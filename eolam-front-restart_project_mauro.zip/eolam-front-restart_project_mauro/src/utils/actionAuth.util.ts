"use server";
import type {FormState} from "@/app/lib/definitionsForm";

import {SignupFormSchema} from "@/app/lib/definitionsForm";
import {createSession, deleteSession} from "@/app/lib/session";

import {userAuth} from "./fetchAuth.utils";
import { loginController } from "@/app/api/_services/UserService";

export async function signup(state: FormState, formData: FormData) {
  const validatedFields = SignupFormSchema.safeParse({
    user: formData.get("user"),
    password: formData.get("password"),
  });

  if (!validatedFields.success) {
    return {
      errors: validatedFields.error.flatten().fieldErrors,
    };
  }

  const {user, password} = validatedFields.data;
  const data = await loginController(user, password);

  if ("error" in data) {
    return {
      error: data.message,
    };
  }
  const {is_admin, email} = data;

  if(!is_admin || !email) {
	return {
		error: 'No se pudo crear la sesión',
	}
  }
  if (is_admin && email) {
	await createSession(email);
  }
}

export async function logout() {
  deleteSession();
}
