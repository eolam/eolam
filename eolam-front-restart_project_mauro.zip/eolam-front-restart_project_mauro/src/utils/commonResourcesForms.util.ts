import type {GetExercisesByReportAndStage, PostExerciseToUser} from "@/interfaces/exerciseUser";
import type {FieldValues} from "react-hook-form";

import {createNewActivityToAnUser, getExerciseByReportAndStage} from "./fetchExerciseUser.util";
import {getNewReport} from "./localStorage/newReport";

export const FORM_HEAD = [
  "Exercise",
  "Series",
  "Rep Type",
  "Each side",
  "Nro Rep",
  "WL",
  "WR",
  "Weight",
  "Interval",
];

export enum RepetitionType {
  AMOUNT,
  TIME,
}

export enum TrainingStage {
  Mobility = 1,
  Activation,
  Strength,
}

export const repetitionType = [
  {value: RepetitionType.AMOUNT, label: "Cantidad"},
  {value: RepetitionType.TIME, label: "Tiempo"},
];

export interface TotalSRW {
  series: number;
  repetitions: number;
  weight: number;
}

export interface SelectForm {
  value: number;
  label: string;
  name?: string;
  id?: number;
}

export interface FormDataSubmit extends FieldValues {
  id_exercise_type: SelectForm;
  id_repetition_type: SelectForm;
  interval?: number;
  left_weight?: number;
  repetition: number;
  right_weight?: number;
  series: number;
  single_weight?: number;
  check_side: boolean;
}

export const onSubmitForm = async (data: FormDataSubmit, id_training_stage: number) => {
  const {
    id_exercise_type,
    id_repetition_type,
    interval,
    left_weight,
    repetition,
    right_weight,
    series,
    single_weight,
    check_side,
  } = data;

  const currentReport = getNewReport();
  const id_report = currentReport?.id || 0;

  const newExerciseData: PostExerciseToUser = {
    id_report,
    id_training_stage,
    id_exercise_type: id_exercise_type.value,
    id_repetition_type: id_repetition_type.value,
    check_side,
    series,
    repetition,
    left_weight: left_weight ?? 0,
    right_weight: right_weight ?? 0,
    single_weight: single_weight ?? 0,
    interval: interval ?? 0,
  };

  const response = await createNewActivityToAnUser(newExerciseData);

  if ("error" in response) {
    return response;
  }

  const newExercisesMobility = await getExerciseByReportAndStage(id_report, id_training_stage);

  if ("results" in newExercisesMobility) {
    return newExercisesMobility.results;
  }
};

export const totalSrwCalculate = (exercises: GetExercisesByReportAndStage[]) => {
  const tSeries = exercises.reduce((total, {series = 0}) => total + series, 0);

  const tRepetitions = exercises.reduce(
    (total, {id_repetition_type, repetition = 0, check_side}) => {
      if (id_repetition_type === RepetitionType.Time) return total;

      return check_side ? total + repetition * 2 : total + repetition;
    },
    0,
  );

  const tWeight = exercises.reduce(
    (total, {single_weight = 0, left_weight = 0, right_weight = 0, check_side}) => {
      return check_side ? total + left_weight + right_weight : total + single_weight;
    },
    0,
  );

  const rpeToCalculate = exercises.map(({rpe_scale}) => (rpe_scale ? rpe_scale.scale : 0));
  const pRpe = (
    rpeToCalculate.reduce((total, scale) => total + scale, 0) / exercises.length
  ).toFixed(2);

  return {tSeries, tRepetitions, tWeight, pRpe};
};
