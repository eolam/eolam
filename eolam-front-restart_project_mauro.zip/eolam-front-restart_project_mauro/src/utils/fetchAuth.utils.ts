/* eslint-disable no-console */
import type {ResponseError} from "@/interfaces/error.interface";

import {fetchJSON} from "@/app/helpers/fetch.helper";

import {baseUrl} from "./route.util";

export interface UserAuth {
  name?: string;
  last_name?: string;
  birthday?: string;
  is_admin?: boolean;
  id?: string;
  token?: string;
  email?: string;
  error?: string;
  status?: number;
  message?: string;
}

const route = `${baseUrl}/api/auth/localAuth`;

export const userAuth = async (
  user: string,
  password: string,
): Promise<ResponseError | UserAuth> => {
  try {
    const requestOptions = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({user, password}),
    };

    const response = await fetchJSON<UserAuth>(route, requestOptions);

    return response;
  } catch (error) {
    const err = error as Error;

    console.error(err);

    throw new Error(err.message);
  }
};
