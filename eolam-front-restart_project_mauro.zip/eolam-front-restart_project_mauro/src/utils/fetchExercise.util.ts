import type {ResponseOk} from "@/interfaces/response.interface";
import type {ExerciseType} from "@/interfaces/exerciseType.interface";
import type {ResponseError} from "@/interfaces/error.interface";

import {fetchJSON} from "@/app/helpers/fetch.helper";

import {baseUrl} from "./route.util";

const route = `${baseUrl}/exercise_type`;

export const createNewActivity = async ({
  name,
  src,
}: {
  name: string;
  src: string;
}): Promise<ResponseOk<ExerciseType> | ResponseError> => {
  try {
    const requestOptions = {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({name, src}),
    };

    const response = await fetchJSON<ResponseOk<ExerciseType>>(route, requestOptions);

    return response;
  } catch (error) {
    const err = error as Error;

    throw new Error(err.message);
  }
};

export const getAllVideos = async (
  page?: number,
  search?: string,
  items = 20,
): Promise<ResponseOk<ExerciseType> | ResponseError> => {
  try {
    const response = await fetchJSON<ResponseOk<ExerciseType>>(
      `${route}?page=${page}&items=${items}${search ? "&search=" + search : ""}`,
    );

    return response;
  } catch (error) {
    const err = error as Error;

    throw new Error(err.message);
  }
};

export const deleteExcerciseById = async (id: number) => {
  try {
    const requestOptions = {
      method: "DELETE",
    };

    const response = await fetchJSON(`${route}/${id}`, requestOptions);

    return response;
  } catch (error) {
    const err = error as Error;

    throw new Error(err.message);
  }
};
