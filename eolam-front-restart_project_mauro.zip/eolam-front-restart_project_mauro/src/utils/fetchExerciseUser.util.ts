import type {ResponseOk} from "@/interfaces/response.interface";
import type {ResponseError} from "@/interfaces/error.interface";
import type {
  GetExercisesByReportAndStage,
  PostExerciseToUser,
  UpdateExerciseType,
} from "@/interfaces/exerciseUser";
import type {ExerciseUser} from "@/interfaces/user.interfaces";

import {fetchJSON} from "@/app/helpers/fetch.helper";

import {baseUrl} from "./route.util";

const route = `${baseUrl}/exercise_user`;

export const createNewActivityToAnUser = async (
  payload: PostExerciseToUser,
): Promise<ResponseOk<ExerciseUser> | ResponseError> => {
  try {
    const requestOptions = {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(payload),
    };

    const response = await fetchJSON<ResponseOk<ExerciseUser> | ResponseError>(
      route,
      requestOptions,
    );

    if ("error" in response) {
      return response;
    }

    return response;
  } catch (error) {
    const err = error as Error;

    throw new Error(err.message);
  }
};

export const getExerciseByReportAndStage = async (
  id_report: number,
  id_training_stage: number,
): Promise<ResponseOk<GetExercisesByReportAndStage> | ResponseError> => {
  try {
    const response = await fetchJSON<ResponseOk<ExerciseUser>>(
      `${route}/report/${id_report}/training_stage/${id_training_stage}`,
    );

    return response;
  } catch (error) {
    const err = error as Error;

    throw new Error(err.message);
  }
};

export const deleteExerciseUser = async (id_exerciser_user: number) => {
  try {
    const requestOptions = {
      method: "DELETE",
      headers: {"Content-Type": "application/json"},
    };

    const response: Response = await fetch(`${route}/${id_exerciser_user}`, requestOptions);

    return response;
  } catch (error) {
    const err = error as Error;

    throw new Error(err.message);
  }
};

export const updateExerciseUser = async (id_exercise: number, payload: UpdateExerciseType) => {
  try {
    const requestOptions = {
      method: "PUT",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(payload),
    };

    const response: Response = await fetch(`${route}/${id_exercise}`, requestOptions);

    return response;
  } catch (error) {
    const err = error as Error;

    throw new Error(err.message);
  }
};
