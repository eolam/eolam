import type {PaymentMethod, PaymentMethodPUT} from "../interfaces/paymentMethod.interface";
import type {ResponseOk} from "@/interfaces/response.interface";

import {fetchJSON} from "@/app/helpers/fetch.helper";

import {baseUrl} from "./route.util";

const route = `${baseUrl}/payment_method`;

export const updatePaymentMethod = async (id_method: number, payload: PaymentMethodPUT) => {
  try {
    const requestOptions = {
      method: "PUT",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(payload),
    };

    const response = await fetchJSON<ResponseOk<PaymentMethod>>(
      `${route}/${id_method}`,
      requestOptions,
    );

    return response;
  } catch (error) {
    const err = error as Error;

    throw new Error(err.message);
  }
};
