import type {ResponseOk} from "@/interfaces/response.interface";
import type {ResponseError} from "@/interfaces/error.interface";
import type {InExercise} from "@/app/api/_models/User.model";

import {fetchJSON} from "@/app/helpers/fetch.helper";

const route = `/api/exercise`;

export const postNewExercise = async (
  id_week: number,
): Promise<ResponseOk<InExercise> | ResponseError> => {
  try {
    const requestOptions = {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({id_week}),
    };

    const response = await fetchJSON<ResponseOk<InExercise>>(route, requestOptions);

    return response;
  } catch (error) {
    const err = error as Error;

    throw new Error(err.message);
  }
};

export const changeStatusTraining = async (status: boolean, id_report: number) => {
  try {
    const requestOptions = {
      method: "PUT",
      headers: {"Content-Type": "application/json"},
    };

    const response = await fetchJSON(`${route}/status/${id_report}/${status}`, requestOptions);

    return response;
  } catch (error) {
    const err = error as Error;

    throw new Error(err.message);
  }
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const deleteReport = async (id_report: number): Promise<ResponseOk<any> | ResponseError> => {
  try {
    const requestOptions = {
      method: "DELETE",
      headers: {"Content-Type": "application/json"},
    };

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const response = await fetchJSON<ResponseOk<any>>(`${route}/${id_report}`, requestOptions);

    return response;
  } catch (error) {
    const err = error as Error;

    throw new Error(err.message);
  }
};
