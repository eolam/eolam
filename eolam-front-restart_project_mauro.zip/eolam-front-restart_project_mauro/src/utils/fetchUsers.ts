"use server";
import type {ListUserReduced, User, UserID} from "@/interfaces/user.interfaces";
import type {ResponseOk} from "@/interfaces/response.interface";
import type {ResponseError} from "@/interfaces/error.interface";

import {cache} from "react";

import {verifySession} from "@/app/lib/session";
import {fetchJSON} from "@/app/helpers/fetch.helper";

const route = `/api/user`;

export async function getReducedListUsers(
  id?: number,
  search?: string,
  page = 1,
  items = 5,
): Promise<ResponseOk<ListUserReduced> | ResponseError> {
  try {
    const routeGet = id
      ? `${route}/${id}`
      : `${route}/?page=${page}&items=${items}${search ? "&search=" + search : ""}`;
    const response = await fetchJSON<ResponseOk<ListUserReduced>>(routeGet);

    return response;
  } catch (error) {
    const err = error as Error;

    throw new Error(err.message);
  }
}

export async function getUserById(id: number): Promise<ResponseOk<User> | ResponseError> {
  try {
    const response = await fetchJSON<ResponseOk<User>>(`${route}/${id}`);

    return response;
  } catch (error) {
    const err = error as Error;

    throw new Error(err.message);
  }
}

export async function getUserByUsername(
  username: string,
): Promise<ResponseOk<User> | ResponseError> {
  try {
    const response = await fetchJSON<ResponseOk<User>>(`${route}/email/${username}`);

    return response;
  } catch (error) {
    const err = error as Error;

    throw new Error(err.message);
  }
}

export async function getUserCurrentSession() {
  const currentSession = await cachedGetUserSession();

  return currentSession;
}

export async function cachedGetUserSession() {
  return cache(async () => {
    const session: UserID = await verifySession();
    const response = await fetchJSON<ResponseOk<User>>(`${route}/${session.userId}`);

    return response;
  })();
}
