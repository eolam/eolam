import type {InUser} from "@/app/api/_models/User.model";
import type {ResponseOk} from "@/interfaces/response.interface";
import type {ResponseError} from "@/interfaces/error.interface";
import type {NewWeek} from "@/interfaces/week.interface";

import {fetchJSON} from "@/app/helpers/fetch.helper";

const route = `/api/user/training/`;

export const postNewWeek = async ({
  id_user,
  week_number,
}: {
  id_user: number;
  week_number: number;
}): Promise<ResponseOk<NewWeek> | ResponseError> => {
  try {
    const requestOptions = {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({id_user, week_number}),
    };

    const response = await fetchJSON<ResponseOk<NewWeek>>(route, requestOptions);

    return response;
  } catch (error) {
    const err = error as Error;

    throw new Error(err.message);
  }
};

export const getUserTrainingHistoryById = async (id: string): Promise<InUser | ResponseError> => {
  try {
    const response = await fetchJSON<InUser | ResponseError>(`${route}/${id}`);

    return response;
  } catch (error) {
    const err = error as Error;

    throw new Error(err.message);
  }
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const deleteWeek = async (id: number): Promise<ResponseOk<any> | ResponseError> => {
  try {
    const requestOptions = {
      method: "DELETE",
      headers: {"Content-Type": "application/json"},
    };

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const response = await fetchJSON<ResponseOk<any>>(`${route}/${id}`, requestOptions);

    return response;
  } catch (error) {
    const err = error as Error;

    throw new Error(err.message);
  }
};
