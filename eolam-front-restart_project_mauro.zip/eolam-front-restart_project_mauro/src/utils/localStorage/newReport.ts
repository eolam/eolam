export const getNewReport = (): CurrenReport | undefined => {
  const actualyReport: string | null = localStorage.getItem("new_exercise");

  if (actualyReport) {
    try {
      const reportJSON = JSON.parse(actualyReport) as CurrenReport;

      return reportJSON;
    } catch (error) {
      return undefined;
    }
  }

  return undefined;
};

interface CurrenReport {
  id: number;
  report_number: number;
  status: boolean;
  week_number: number;
  date?: string;
}
