export const baseUrl = process.env.API_URL;
